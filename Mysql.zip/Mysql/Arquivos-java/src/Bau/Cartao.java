package Bau;

public class Cartao {
    private double saldo;

    public Cartao() {
        this.saldo = 0.0;
    }

    public void recarregar(double valor) {
        this.saldo += valor;
        System.out.println("Recarga de " + valor + " realizada com sucesso.");
        System.out.println("Saldo Atual: " + this.saldo);
    }

    public double conferirSaldo() {
        System.out.println("Saldo atual: " + this.saldo);
        return this.saldo;
    }

    public boolean debitar(double valor) {
        if (this.saldo >= valor) {
            this.saldo -= valor;
            System.out.println("Débito de " + valor + " realizado com sucesso.");
            System.out.println("Saldo Atual: " + this.saldo);
            return true;
        } else {
            System.out.println("Saldo insuficiente para debitar " + valor);
            System.out.println("Saldo Atual: " + this.saldo);
            return false;
        }
    }
}

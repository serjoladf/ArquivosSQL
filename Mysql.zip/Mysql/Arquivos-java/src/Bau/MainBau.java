package Bau;

import java.util.Scanner;

public class MainBau {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.print("Digite seu nome: ");
        String nomeCliente = leitor.nextLine();
        Cliente cliente = new Cliente(nomeCliente);

        Cartao cartao = new Cartao();

        System.out.print("Digite a opcao desejada: 1 para Recarregar, 2 Para Saldo: ");
        int opcao = leitor.nextInt();

        switch (opcao) {
            case 1:
                System.out.print("Digite o valor a ser recarregado: ");
                double valorRecarregar = leitor.nextDouble();
                cartao.recarregar(valorRecarregar);
                break;

            case 2:
                cartao.conferirSaldo();
                break;

            default:
                System.out.println("Opção inválida!");
        }

        System.out.print("Digite o valor da passagem: ");
        double valorDebitar = leitor.nextDouble();
        boolean debitoRealizado = cartao.debitar(valorDebitar);

        if (debitoRealizado) {
            System.out.println("Debitado com sucesso!");
        } else {
            System.out.println("Saldo insuficiente!");
        }

        leitor.close();
    }
}

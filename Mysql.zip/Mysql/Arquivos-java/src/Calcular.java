public class Calcular {
    
    double aliquota;
    double salario;
    double beneficio;

    // Constructor to initialize instance variables
    public Calcular(double salario, double beneficio) {
        this.salario = salario;
        this.beneficio = beneficio;
        calcular(); // Automatically calculate aliquota upon object creation
    }

    private void calcular() {
        if (salario >= 0 && salario <= 1100) {
            aliquota = 0.05;
        } else if (salario > 1100 && salario <= 2500) {
            aliquota = 0.10;
        } else {
            aliquota = 0.15;
        }
    }

    public void mostrarSalario(String nomeFuncionario) {
        double desconto = salario * aliquota;
        double valorApagar = salario - desconto + beneficio;
        System.out.println("O salário líquido de " + nomeFuncionario + " é de R$ " + valorApagar + " Reais");
    }
}

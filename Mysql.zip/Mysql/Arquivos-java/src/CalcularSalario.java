import java.util.Scanner;

public class CalcularSalario {
    public static void main(String[] args) {
        Scanner leitorDados = new Scanner(System.in);

        // Prompt user to enter employee details
        System.out.println("Digite o Nome do Funcionário:");
        String nomeFuncionario = leitorDados.nextLine();

        System.out.println("Digite o valor do salário do Funcionário:");
        double salario = leitorDados.nextDouble();

        System.out.println("Digite o valor do benefício:");
        double beneficio = leitorDados.nextDouble();

        // Create an instance of Calcular
        Calcular calcular = new Calcular(salario, beneficio);

        // Call mostrarSalario method to display the calculated salary
        calcular.mostrarSalario(nomeFuncionario);

        // Close scanner to prevent resource leak
        leitorDados.close();
    }
}

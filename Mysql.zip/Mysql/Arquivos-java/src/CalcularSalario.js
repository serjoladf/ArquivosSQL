
        var nomeFuncionario = prompt(" Digite o Nome do Funcionário: ");

        var salario = parseFloat(prompt(" Digite o Salario do Funcionário: "));

        var beneficio = parseFloat(prompt(" Digite o valor do benefício: "));

        var aliquota;
        
        if (salario >= 0 && salario <= 1100){

            aliquota = 0.05;

        } 
        
        else if (salario > 1100 && salario <= 2500){

            aliquota = 0.10;
        
        }else{

            aliquota = 0.15;

        }
          
        var desconto = salario * aliquota;

        var valorApagar = (salario - desconto + beneficio);

        console.log("O seu salario com descontos mais beneficio "+nomeFuncionario+" é de R$ "+ valorApagar+" Reais");



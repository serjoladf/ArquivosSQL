
DELIMITER $$
CREATE PROCEDURE atualizar_cliente(
    IN p_ID INT,
    IN p_NOME VARCHAR(150),
    IN p_CPF_CNPJ VARCHAR(14),
    IN p_RG VARCHAR(20),
    IN p_ORGAO_RG VARCHAR(10),
    IN p_INSCRICAO_ESTADUAL VARCHAR(30),
    IN p_INSCRICAO_MUNICIPAL VARCHAR(30),
    IN p_DESDE DATE,
    IN p_TIPO_PESSOA CHAR(1),
    IN p_EXCLUIDO CHAR(1),
    IN p_DATA_CADASTRO DATE
)
BEGIN
 UPDATE cliente
    SET 
        nome = p_NOME,
        CPF_CNPJ = p_CPF_CNPJ,
        RG = p_RG,
        ORG_RG = p_ORGAO_RG,
        inscricao_Estadual = p_INSCRICAO_ESTADUAL,
        Inscricao_municipal = p_INSCRICAO_MUNICIPAL,
        desde = p_DESDE,
        tipo_pessoa = p_TIPO_PESSOA,
        EXCLUIDO = p_EXCLUIDO,
        data_cadastro = p_DATA_CADASTRO
	WHERE id = p_ID;
    
    INSERT INTO LOG_CLIENTE (acao, id, nome, CPF_CNPJ, RG, ORG_RG, inscricao_Estadual, Inscricao_municipal, desde, tipo_pessoa, EXCLUIDO, data_cadastro)
    VALUES ('Antigo', OLD.id, OLD.nome, OLD.CPF_CNPJ, OLD.RG, OLD.ORG_RG, OLD.inscricao_Estadual, OLD.Inscricao_municipal, OLD.desde, OLD.tipo_pessoa, OLD.EXCLUIDO, OLD.data_cadastro);

    INSERT INTO LOG_CLIENTE (acao, id, nome, CPF_CNPJ, RG, ORG_RG, inscricao_Estadual, Inscricao_municipal, desde, tipo_pessoa, EXCLUIDO, data_cadastro)
    VALUES ('Atualização', NEW.id, NEW.nome, NEW.CPF_CNPJ, NEW.RG, NEW.ORG_RG, NEW.inscricao_Estadual, NEW.Inscricao_municipal, NEW.desde, NEW.tipo_pessoa, NEW.EXCLUIDO, NEW.data_cadastro);

END $$
DELIMITER ;



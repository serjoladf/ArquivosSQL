SELECT * FROM exercicio_abd.sala;

insert INTO sala(numero,qt_max_aluno,turma_id)
 VALUES(11, 25, 1),
(12, 25, 2),
(13, 25, 3),
(14, 25, 4),
(15, 25, 5);
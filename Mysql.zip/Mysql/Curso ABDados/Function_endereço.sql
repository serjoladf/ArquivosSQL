DELIMITER $$
create function enderecoCompleto(idCliente int)
returns varchar(500)
deterministic
begin
declare enderecoCompleto varchar(500);
select
concat(e.LOGRADOURO,' ',e.numero,' ',e.complemento,' ',e.bairro,' ',c.CEP)
into enderecoCompleto
from endereco e
inner join cep c on c.ID = e.CEP_ID
where idCliente = e.cliente_id;
return enderecoCompleto;
end$$
DELIMITER ;

select nome,enderecoCompleto(5) as endereço from cliente where id=5;
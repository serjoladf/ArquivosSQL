/* MySQL Workbench - Procedure confere se o numero é primo ou não*/

delimiter $$
create procedure conferindo_se_primo(numb int)
begin
    declare verificador int default 0;
    declare contador int default 0;
    declare divisor int default numb;
	declare resul int default 0;
	while contador < numb and numb <> 1 and numb <> 2 do
		if divisor <= numb  and numb % 2 = 1 then
			set resul = numb % divisor ;
            if resul = 0 then set verificador = verificador + 1;
			end if;
            set divisor = divisor - 1;
		end if;
	SET contador = contador + 1;
END WHILE;
	select
    numb as Número,
	Case
		when numb = 1 then "Este Número não é primo"
		when numb = 2 then "Este é o único número par que é primo"
		when verificador = 2 or numb = 2 then "Este número é primo"
		else
			"Este Número não é primo"
	end as "PRIMO";
end$$
delimiter ;

call conferindo_se_primo(18); 
select
c.nome_colaborador as nome_colaborador,
c.dataNascimento,
ca.nome_cargo as nome_cargo,
retor_idade(c.dataNascimento)
from colaborador as c
inner join cargo ca on ca.id = c.cargo_id
where
retor_idade(c.dataNascimento) > 40;

/* where
retor_idade(c.dataNascimento)
between 25 and 40;
DELIMITER $$
CREATE FUNCTION retorne_relatorio(id int)
RETURNS varchar(1000)
DETERMINISTIC
BEGIN
DECLARE retorne_relatorio varchar(1000);
select 
concat(c.nome, ' - ',
c.cpf, ' - ',
op.descricao, ' - ',
op.data_servico, ' - ',
i.tipo_residencia, ' - ',
i.descricao, ' - ',
i.dia_contrato, ' - ',
i.valor_estimado, ' - ',
i.cond_status)
into retorne_relatorio
from clientes as c
inner join operacao as op on c.id = op.id
inner join endereco as e on e.id = c.endereco_id
inner join imovel as i on i.id = e.id
where c.id = id;
RETURN retorne_relatorio;
END$$
delimiter ;


select retorne_relatorio(1) 
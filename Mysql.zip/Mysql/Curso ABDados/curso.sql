SELECT * FROM exercicio_abd.curso;

INSERT INTO curso(nome,modalidade,carga_horaria,turma_id)
VALUES
("medicia","hibrido" ,1240 ,1),
("fisica","presencial" ,1250 ,2),
("direito","online" ,1260 ,3),
("portugues","hibrido" ,1270 ,4),
("matematica","presencial" ,1280 ,5);

ALTER TABLE CURSO RENAME COLUMN NOME TO nome_curso;

select 
modalidade,
count(modalidade) as tipos_modalidade
-- sum(dp.carga_horaria) AS total_horas
from disciplina AS dp
inner join curso_has_disciplina As cd on dp.id = cd.disciplina_id
inner join curso As cr on cd.curso_id = cr.id
group by
modalidade;
SELECT Nome_Fornecedor
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor < 2.60);


SELECT*
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor = 2.10);

SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND not valor < 2.60);


SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor = 2.10);

SELECT  f.nome_fornecedor, p.nome_produto, p.valor
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND not valor < 2.60);
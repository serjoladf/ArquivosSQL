SELECT * FROM exercicio_abd.sexo;

INSERT INTO sexo(descricao)
VALUES ("masculino"),
("feminino");

select 
s.descricao,
count(*) as total_sexo
from aluno a
inner join sexo s on s.id = a.sexo_id
inner join professor p on s.id = p.sexo_id
-- inner join turma_has_aluno ta on ta.aluno_id = a.id
-- inner join turma t on t.id = ta.turma_id
-- inner join turma_has_curso tc on tc.turma_id = t.id
-- inner join curso c on c.id = tc.curso_id
-- inner join turma_has_professor tp on tp.turma_id = t.id
-- inner join professor on p.id = tp.professor_id
group by s.descricao;
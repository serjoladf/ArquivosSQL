SELECT * FROM empresa.email;

CREATE TABLE email(
id INT AUTO_INCREMENT PRIMARY KEY,
email  VARCHAR(50),
email_2  VARCHAR(50)
);

INSERT INTO email(email) VALUES
("daniela@gmail.com"),("bondedf@hotmail.com"),("idetres@ibest.com"),("sorriso@hotmail.com");

ALTER TABLE email DROP COLUMN email_2;

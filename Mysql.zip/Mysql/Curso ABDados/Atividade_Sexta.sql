-- Adicione uma restrição CHECK à tabela pessoas para garantir que a idade de qualquer pessoa inserida esteja entre 18 e 100 anos

ALTER TABLE Pessoas
ADD CONSTRAINT CHK_PessoaIdade CHECK (Idade>18 AND Idade<100);

 -- Modifique a tabela produtos para garantir que a quantidade de qualquer produto inserido seja não negativa.

ALTER TABLE produtos
ADD CONSTRAINT CHK_ProdutosPos CHECK (quantidade >=0);

-- Exercícios sobre DEFAULT

 -- Altere a tabela PRODUTOS para que o campo Preco tenha um valor padrão de 1.00 quando nenhum valor  específico for fornecido no momento da inserção.
 
 ALTER TABLE produtos
ALTER valor SET DEFAULT 1.00;

--  Remova o valor padrão atual da coluna Data_Pedido na tabela pedidos

ALTER TABLE Pedidos
ALTER Data_pedido DROP DEFAULT;

-- Escreva uma consulta para verificar se existe algum produto com preço maior que 25.

SELECT*
FROM produtos p
WHERE EXISTS (SELECT p.Nome_Produto FROM fornecedor f WHERE Fornecedor_id = f.Id AND valor > 25);

-- Escreva uma consulta para encontrar os nomes de fornecedores que têm produtos listados na tabela produtos.

SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE p.valor > 0);

-- Selecione todos os pedidos que tenham um Numero_Pedido igual a qualquer número de pedido registrado na  tabela pedidos que seja maior que 10.

SELECT
f.nome_fornecedor as Fornecedor, 
p.quantidade as Quantidade,
p.nome_produto as Produto,
p.valor as "Valor R$"
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE p.id = ANY
(SELECT id 
FROM pedidos
WHERE numero_pedido > 10 ); 

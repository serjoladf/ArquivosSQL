CREATE DATABASE Exercicio_abd;

USE Exercicio_abd;


CREATE TABLE turma(id INT AUTO_INCREMENT PRIMARY KEY, cod_da_turma VARCHAR (20), turno VARCHAR(100), data_inicio DATE,  data_fim DATE);

CREATE TABLE sexo(id INT AUTO_INCREMENT PRIMARY KEY, descricao varchar(200));

CREATE TABLE professor(id INT AUTO_INCREMENT PRIMARY KEY UNIQUE, nome Varchar(200) NOT NULL, cpf varchar(20) UNIQUE,rg VARCHAR(20) UNIQUE,
dataNasc DATE,email Varchar(50), cor_de_pele varchar(45), matricula varchar(30), telefone varchar(20), lotacao varchar(30), 
nacionalidade varchar(50), naturalidade varchar(50), turma_id INT, sexo_id INT,
foreign key (sexo_id) REFERENCES sexo (id)
);

CREATE TABLE aluno(id INT AUTO_INCREMENT PRIMARY KEY UNIQUE, nome Varchar(200) NOT NULL, cpf varchar(20) UNIQUE,rg VARCHAR(20) UNIQUE,
dataNasc DATE,email Varchar(50), cor_de_pele varchar(45), etnia varchar(30), telefone varchar(20),
nacionalidade varchar(50), naturalidade varchar(50), turma_id int,  sexo_id INT, login_id INT,
FOREIGN KEY (sexo_id) REFERENCES sexo (id),
FOREIGN KEY (login_id) REFERENCES login (id)
 );

CREATE TABLE sala(id INT auto_increment primary KEY, numero INT, qt_max_aluno INT, turma_id INT);

CREATE TABLE curso(id INT auto_increment primary KEY, nome varchar(20), modalidade varchar(100), carga_horaria INT,turma_id INT);

CREATE TABLE disciplina(id INT auto_increment primary KEY,nome varchar(200), carga_horaria INT, curso_id INT);

CREATE TABLE login(id INT auto_increment primary KEY, senha varchar(20), usuario varchar(100), aluno_id int);
CREATE TABLE turma_has_aluno(
turma_id int,
aluno_id int,
foreign key (turma_id) references turma(id),
foreign key (aluno_id) references aluno(id));


CREATE TABLE turma_has_professor(
turma_id int,
professor_id int,
foreign key (turma_id) references turma(id),
foreign key (professor_id) references professor(id));

CREATE TABLE curso_has_disciplina(
curso_id int,
disciplina_id int,
foreign key (curso_id) references curso(id),
foreign key (disciplina_id) references disciplina(id));

CREATE TABLE turma_has_curso(
turma_id int,
curso_id int,
foreign key (turma_id) references turma(id),
foreign key (curso_id) references curso(id));

CREATE TABLE turma_has_sala(
turma_id int,
sala_id int,
foreign key (turma_id) references turma(id),
foreign key (sala_id) references sala(id));



select 
a.nome,
a.cpf,
a.datanasc,
a.email,
s.descricao,
t.turno,
t.data_inicio,
t.data_fim,
c.nome_curso,
c.modalidade,
c.carga_horaria ch_curso,
p.nome nome_professor,
p.matricula,
p.cpf cfp_professor
from aluno a
inner join sexo s on s.id = a.sexo_id
inner join turma_has_aluno ta on ta.aluno_id = a.id
inner join turma t on t.id = ta.turma_id
inner join turma_has_curso tc on tc.turma_id = t.id
inner join curso c on c.id = tc.curso_id
inner join turma_has_professor tp on tp.turma_id = t.id
inner join professor p on p.id = tp.professor_id;



select * from turma_has_aluno;

select * from sexo;


	SELECT*FROM aluno AS al
	left JOIN turma AS tm ON al.id = tm.id
	left JOIN curso AS cr ON al.id = cr.id
	left JOIN sexo AS sx ON al.sexo_id = sx.id
	left JOIN disciplina AS ds ON al.id = ds.id;
    
  	SELECT*FROM aluno AS al
	right JOIN turma AS tm ON al.id = tm.id
	right JOIN curso AS cr ON al.id = cr.id
	right JOIN sexo AS sx ON al.sexo_id = sx.id
	right JOIN disciplina AS ds ON al.id = ds.id;
    
	SELECT*FROM aluno AS al
	inner JOIN turma AS tm ON al.id = tm.id
	inner JOIN curso AS cr ON al.id = cr.id
	inner JOIN login AS lg ON al.id = lg.id
	inner JOIN disciplina AS ds ON al.sexo_id = ds.id;


	SELECT COUNT(*) AS nome FROM aluno;
    

	SELECT 
	disciplina,
	COUNT(disciplina) qt_disciplina 
	FROM curso
	GROUP BY disciplina;
    
	SELECT COUNT(*) as tota_usuarios FROM usuarios US
	INNER JOIN reserva RS ON rs.idusuario = US.id;
    
    SELECT COUNT(*) as total_disciplina FROM disciplina As dp
	INNER JOIN curso cr ON cr.id = dp.id;
    
-- disciplina(nome,carga_horaria,curso_id)
-- curso(nome,modalidade,carga_horaria,turma_id)

select nome_curso, nome_disciplina, count(nome_disciplina) total_disciplina
from disciplina AS dp
INNER JOIN curso AS cr  ON dp.curso_id = cr.id
group by nome_curso,nome_disciplina;
	

select nome_curso, nome_disciplina, count(*) total_disciplina
from disciplina AS dp
INNER JOIN curso AS cr  ON cr.curso_id = cr.id
INNER JOIN curso_has_disciplina AS cd  ON cd.curso_id = cd.disciplina_id
INNER JOIN disciplina ON dp.id = cd.disciplina_id
group by nome_curso,nome_disciplina;

SELECT
nome_curso, nome_disciplina,
COUNT(nome_disciplina) as total_disciplina
FROM disciplina As dp
INNER JOIN curso  ON dp.curso_id = curso.id
GROUP by nome_curso, nome_disciplina;

SELECT
nome_curso, nome_disciplina,
COUNT(nome_curso) as total_disciplina
FROM disciplina As dp
INNER JOIN curso  ON dp.curso_id = curso.id
GROUP by nome_curso, nome_disciplina;


select 
cr.nome_curso, modalidade, 
count(modalidade) as tipos_modalidade,
sum(cr.carga_horaria) AS total_horas,
dp.carga_horaria,
dp.nome_disciplina,
sum(cr.carga_horaria - dp.carga_horaria) as carga_h_restante
from disciplina AS dp
inner join curso_has_disciplina As cd on dp.id = cd.disciplina_id
inner join curso As cr on cd.curso_id = cr.id
group by
cr.nome_curso, dp.nome_disciplina, dp.carga_horaria, modalidade;



select 
pr.nome_professor,
cr.nome_curso,
tu.turno,
tu.cod_da_turma,
count(dp.nome_disciplina) AS total_professores
from professor as pr
inner join turma_has_professor AS tp on pr.id = tp.professor_id
inner join turma As tu on tp.turma_id = tu.id
inner join turma_has_curso AS tc on tu.id = tc.turma_id
inner join curso As cr on tc.curso_id = cr.id
inner join curso_has_disciplina AS cd on cr.id = cd.curso_id
-- inner join disciplina AS dp on dp.id = cd.disciplina_id
inner join disciplina AS dp on pr.id = dp.id
group by pr.nome_professor,
cr.nome_curso,
dp.nome_disciplina,
tu.turno,
tu.cod_da_turma;


select 
s.descricao,
count(*) as total_sexo
from professor p
inner join sexo s on s.id = p.sexo_id
group by s.descricao;

select 
s.descricao,
count(*) as total_sexo
from aluno a
inner join sexo s on s.id = a.sexo_id
group by s.descricao;

select 
s.descricao,
count(*) as total_sexo
from aluno a 
inner join sexo s on s.id = a.sexo_id
inner join professor p on s.id = p.sexo_id
group by s.descricao;
DELIMITER $$
CREATE FUNCTION retor_idade (dataNascimento date)
RETURNS int
DETERMINISTIC
BEGIN
 RETURN timestampdiff(year,dataNascimento,curdate());
END$$
DELIMITER ;


select dataNascimento, retor_idade(dataNascimento) idade from colaborador;


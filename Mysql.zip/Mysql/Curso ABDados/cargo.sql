SELECT * FROM senai.professor;

UPDATE professor
SET email = "astucio@gmail.com"
WHERE id=4;

alter table professor add column  nome VARCHAR(30);
delete from professor where id = 22;

ALTER TABLE professor
MODIFY COLUMN id INT AUTO_INCREMENT, 
ADD PRIMARY KEY (id);

SELECT * FROM senai.professor ORDER BY salario DESC;

SELECT 
sexo,
COUNT(sexo) qt_sexo
FROM professor
GROUP BY sexo;

SELECT 
COUNT(*) sexo
FROM professor;


SELECT
CASE
WHEN sexo = 'F' THEN "FEMININO"
WHEN sexo = 'M' THEN "MASCULINO"
END sexo
FROM professor;



SELECT
id,
nome,
cpf,
email,
CASE
WHEN sexo = 'F' THEN "FEMININO"
WHEN sexo = 'M' THEN "MASCULINO"
END sexo
FROM professor;

insert into professor(cpf,email,sexo,rg,salario,nome)
values("015.187.077-77", "jane@gmail.com",'F', 2987690,1230.05,"jane"),
( "016.345.074-66", "lucas_drg@gmail.com",'M',2987690,1456.15,"Lucas"),
("017.446.075-88", "brendinha@gmail.com",'F',2987690,1430.85,"Brenda");

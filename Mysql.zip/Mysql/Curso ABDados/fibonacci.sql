delimiter $$
create procedure fibonacci2(numb int)
begin
    declare numb1 int default 0;
    declare somador int default 1;
    declare contador int default 0;
	declare result int default 1;
    select 0;
	while contador < numb  do
    select
    result;
		set result = numb1+somador;
		set numb1 = somador ;
		set somador = result;
	SET contador = contador + 1;
END WHILE;
	select
     numb as Número,
     result as Total_fibonacci;
end$$
delimiter ;

call fibonacci2(5);
select
count(nome_produto) as "Q.produto",
round(AVG(pd.valor_venda),2) as "Média compra"
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id
group by pd.descricao;


select
pd.descricao,
count(pd.descricao) as Industrias
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id
group by pd.descricao;


select
count(nome_produto) as "Q.produto",
round(AVG(pd.valor_venda),2) as "Média compra"
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id;

select
pd.valor_compra, 
pd.valor_venda,	 
concat(round((pd.valor_venda*100/pd.valor_compra),2),"%" ) as Margem_lucro
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id;
-- where fr.CPF_CNPJ = "254543543100";


select
fr.nome,
fr.CPF_CNPJ,
fr.inscricao_Estadual,
fr.DATA_CADASTRO,
tf.nome,
tf.descricao,
pd.nome_produto,
pd.descricao,
pd.quant_estoque,
pd.valor_compra,
pd.valor_venda,
concat(round((pd.valor_venda - pd.valor_compra),2),"" ) as Valor_lucro,
concat(round((pd.valor_venda*100/pd.valor_compra),2),"%" ) as Margem_lucro,
concat((quant_estoque * valor_compra)," Reais") as Valor_estoque
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id;

select
fr.nome,
fr.CPF_CNPJ,
fr.inscricao_Estadual,
fr.DATA_CADASTRO,
tf.nome,
tf.descricao,
pd.nome_produto,
pd.descricao,
pd.quant_estoque,
pd.valor_compra,
pd.valor_venda,
concat(round((pd.valor_venda - pd.valor_compra),2),"" ) as Valor_lucro,
concat(round((quant_estoque * (pd.valor_venda - pd.valor_compra)),2),"" ) as Lucro_Total,
concat(round(((pd.valor_venda*100/pd.valor_compra)-100),2),"%" ) as Margem_lucro,
concat((quant_estoque * valor_compra)," Reais") as Valor_estoque
FROM fornecedor as fr
inner join fornecedor_produto AS fp on fp.fornecedor_id = fr.id
inner join produto as pd on pd.id = fp.produto_id
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id
where pd.valor_compra < (select avg(valor_compra) from produto);






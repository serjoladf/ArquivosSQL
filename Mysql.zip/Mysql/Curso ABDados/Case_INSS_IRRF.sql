select
col.cpf,
col.nome_colaborador,
col.dataNascimento,
col.DATA_CADASTRO,
st.nome,
c.nome_cargo,
c.salario,							
CASE    
		WHEN c.Salario <= 1212.00 THEN (c.salario * 0.075) -- Primeira Faixa
        WHEN c.Salario >= 1212.00 and c.Salario <= 2427.35 THEN ((c.salario - 1212) * 0.09)+(1212 * 0.075) -- Segunda Faixa
        WHEN c.Salario >= 2427.36 and c.Salario <= 3641.03 THEN ((c.salario - 2427.36)* 0.12)+(1215.36 * 0.09)+(1212 * 0.075) -- Terceira Faixa
        WHEN c.Salario >= 3641.04 and c.Salario <= 7087.22 THEN ((c.salario - 3641.04) * 0.14)+(1213.67* 0.12)+(1215.36 * 0.09)+(1212 * 0.075) -- Quarta Faixa
        ELSE ((C.SALARIO - 7087.22) * 0.14)+(3446.18 * 0.14)+(1213.67* 0.12)+(1215.36 * 0.09)+(1212 * 0.075)
    END AS Desconto_INSS,
    CASE									
       WHEN c.Salario <= 1903.00 THEN 0
        WHEN c.Salario >= 1903.99 and c.Salario <= 2826.65 THEN ((c.salario - 1903) * 0.075)
        WHEN c.Salario <= 2826.66 and c.Salario <= 3751.05 THEN ((c.salario - 2826.66) * 0.15)+(923.66 *0.075)
        WHEN c.Salario <= 3751.06 and c.Salario <= 4664.68 THEN ((c.salario -3751.06) * 0.225)+ (924.4 * 0.15)+(923.66 *0.075)
        ELSE ((C.SALARIO - 4664.68) * 0.275) +(913.62 * 0.225)+ (924.4 * 0.15)+(923.66 *0.075)
    END AS Desconto_IRRF,
    (C.Salario -
    CASE
        WHEN c.Salario <= 1212.00 THEN (c.salario * 0.075)
        WHEN c.Salario >= 1212.00 and c.Salario <= 2427.35 THEN ((c.salario - 1212) * 0.09)+(1212 * 0.075)
        WHEN c.Salario >= 2427.36 and c.Salario <= 3641.03 THEN ((c.salario - 2427.36)* 0.12)+(1215.36 * 0.09)+(1212 * 0.075)
        WHEN c.Salario >= 3641.04 and c.Salario <= 7087.22 THEN ((c.salario - 3641.04) * 0.14)+(1213.67* 0.12)+(1215.36 * 0.09)+(1212 * 0.075)
        ELSE ((C.SALARIO - 7087.22) * 0.14)+(3446.18 * 0.14)+(1213.67* 0.12)+(1215.36 * 0.09)+(1212 * 0.075)
    END -
    CASE
		WHEN c.Salario <= 1903.00 THEN 0
        WHEN c.Salario >= 1903.99 and c.Salario <= 2826.65 THEN ((c.salario - 1903) * 0.075)
        WHEN c.Salario <= 2826.66 and c.Salario <= 3751.05 THEN ((c.salario - 2826.66) * 0.15)+(923.66 *0.075)
        WHEN c.Salario <= 3751.06 and c.Salario <= 4664.68 THEN ((c.salario -3751.06) * 0.225)+ (924.4 * 0.15)+(923.66 *0.075)
        ELSE ((C.SALARIO - 4664.68) * 0.275) +(913.62 * 0.225)+ (924.4 * 0.15)+(923.66 *0.075)
    END) AS Salario_Liquido
FROM fornecedor as fr
inner join tipo_fornecedor AS tf on tf.id = fr.tipo_fornecedor_id
inner join contato AS ct on ct.id = fr.tipo_fornecedor_id
inner join colaborador AS col on ct.colaborador_id = col.id
inner join setor AS st on st.id = col.id_setor
inner join cargo AS c on c.id = col.cargo_id;
-- where COL.cpf = "12033367890";
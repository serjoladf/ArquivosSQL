SELECT * FROM escola.curso;

INSERT INTO curso(nome, modalidade, carga_horaria,turma_id) VALUES("FRONT-END","HIBRIDO",240, 1);
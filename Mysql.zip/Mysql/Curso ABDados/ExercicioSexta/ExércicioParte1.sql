CREATE DATABASE escola;
USE escola;

CREATE TABLE turma(id INT AUTO_INCREMENT PRIMARY KEY, cod_da_turma VARCHAR (20), turno VARCHAR(100), data_inicio DATE,  data_fim DATE);
/* 1 - Primeiro criei TURMA que não faz referencia e sim é a referencia. */

CREATE TABLE sexo(id INT auto_increment primary KEY, descricao varchar(200), aluno_id int, professor_id int);

/* 2 - criei sexo que  não faz referencia. */

CREATE TABLE professor(id INT auto_increment primary KEY, nome Varchar(200) NOT NULL, cpf varchar(20),rg VARCHAR(20),
dataNasc DATE,email Varchar(50), cor_de_pele varchar(45), matricula varchar(30), telefone varchar(20), lotacao varchar(30), 
nacionalidade varchar(50), naturalidade varchar(50), turma_id int, sexo_id INT,
FOREIGN KEY (turma_id) REFERENCES turma (id),
FOREIGN KEY (sexo_id) REFERENCES sexo (id)
);
/* 3 - criei PROFESSOR que faz referencia somente a  turma e sexo. */

CREATE TABLE aluno(id INT auto_increment primary KEY, nome Varchar(200) NOT NULL, cpf varchar(20),rg VARCHAR(20),
dataNasc DATE,email Varchar(50), cor_de_pele varchar(45), etnia varchar(30), telefone varchar(20),
nacionalidade varchar(50), naturalidade varchar(50), turma_id int,  sexo_id INT,
FOREIGN KEY (turma_id) REFERENCES turma (id),
FOREIGN KEY (sexo_id) REFERENCES sexo (id)
 );
 /* 4 - criei PROFESSOR que faz referencia somente a turma e sexo */

CREATE TABLE sala(id INT auto_increment primary KEY, numero INT, qt_max_aluno INT, turma_id INT,
FOREIGN KEY (turma_id) REFERENCES turma(id));

/* 5 - criei SALA que faz referencia somente a turma. */

CREATE TABLE curso(id INT auto_increment primary KEY, nome varchar(20), modalidade varchar(100), carga_horaria INT,turma_id INT, 
FOREIGN KEY (turma_id) REFERENCES turma(id));

/* 6 - criei CURSO que faz referencia somente a turma. */

CREATE TABLE disciplina(id INT auto_increment primary KEY,nome varchar(200), carga_horaria INT, curso_id INT,
FOREIGN KEY (curso_id) REFERENCES curso(id));

/* 5 - criei DISCIPLINA que faz referencia somente ao Curso. */

CREATE TABLE login(id INT auto_increment primary KEY, senha varchar(20), usuario varchar(100), aluno_id int,
FOREIGN KEY (aluno_id) REFERENCES aluno (id));
/* 7 - criei LOGIN que só faz referência a Aluno. */

SHOW TABLES;

SELECT*FROM aluno AS al
INNER JOIN turma AS tm ON al.id = tm.id
INNER JOIN curso AS cr ON al.id = cr.id
INNER JOIN disciplina AS ds ON al.id = ds.id;


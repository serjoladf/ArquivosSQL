SELECT * FROM escola.sala;

INSERT INTO sala(numero, qt_max_aluno, turma_id) VALUES(23, 40, 1);
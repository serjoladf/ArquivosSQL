SELECT * FROM escola.disciplina;

INSERT INTO disciplina(nome,carga_horaria,curso_id)
VALUES("Lógica de Programação", 100,1);
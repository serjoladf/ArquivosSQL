SELECT * FROM escola.login;

INSERT INTO login(senha,usuario,aluno_id)
VALUES("1srg00200","serjoladf",1);

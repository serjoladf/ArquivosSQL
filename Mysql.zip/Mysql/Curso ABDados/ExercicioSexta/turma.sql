SELECT * FROM escola.turma;

INSERT INTO escola.turma ( cod_da_turma, turno, data_inicio, data_fim) 
VALUES ("33A", "matutino", "2024-01-01", "2024-06-01");
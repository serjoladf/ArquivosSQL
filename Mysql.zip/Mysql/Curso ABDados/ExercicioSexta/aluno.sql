SELECT * FROM escola.aluno;
INSERT INTO escola.aluno(nome, cpf, rg, dataNasc, email, cor_de_pele, etnia, telefone,nacionalidade,naturalidade,turma_id,sexo_id)
 VALUES ("Sérgio", "013.609.055-96", "2.659.821", "1982-07-04", "serjolasrg@gmail.com", "Pardo", "africana", "98642-2423", "brasileiro", "Bahia",1,1);
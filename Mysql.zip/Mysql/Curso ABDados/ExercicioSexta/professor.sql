SELECT * FROM escola.professor;

INSERT INTO escola.professor(nome, cpf, rg, dataNasc, email, cor_de_pele, matricula, telefone,lotacao,nacionalidade,naturalidade,turma_id,sexo_id)
 VALUES ("Francisco", "023.605.066-87", "2.674.821", "1982-07-05", "francisco@gmail.com", "Pardo", "2345", "98642-3433", "sem", "brasileiro", "Brasília",1,1);
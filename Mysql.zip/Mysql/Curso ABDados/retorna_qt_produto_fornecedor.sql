DELIMITER $$
create function qt_produto_fornecedor(idFornecedor int)
returns int
deterministic
begin
declare qtdProdutos int;
select count(*) into qtdProdutos
from fornecedor_produto where
FORNECEDOR_ID = idFornecedor;
return qtdProdutos;
end$$
DELIMITER ;


select
NOME,
qt_produto_fornecedor(id)
from fornecedor;
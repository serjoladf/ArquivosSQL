SELECT * FROM exercicio_abd.disciplina;

INSERT INTO disciplina(nome,carga_horaria,curso_id)
VALUES("citologia",35,1),
("trigonometria.",45,2),
("direito previdencia",65,3),
("literátura",90,4),
("Cálculo 3",120,5);


  
  ALTER TABLE disciplina RENAME COLUMN nome TO nome_disciplina;
  
  update disciplina
  set nome_disciplina = "calculo 5"
  where id=15;
  
  
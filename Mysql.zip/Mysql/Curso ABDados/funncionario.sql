SELECT * FROM empresa.funcionario;

INSERT INTO funcionario(nome,rg,cpf,id_cargo)
VALUES("Jose","2659.654","015.509.056-97",1),
("Jose","2659.614","011.509.056-34",1),
("Maria","2659.624","012.509.056-56",2),
("Andre","2659.634","013.509.056-67",3),
("Joe","2659.454","014.509.056-88",4),
("Marcos","2659.664","015.509.056-94",5),
("Leo","2659.684","016.529.056-91",6),
("DLucas","2659.694","017.509.056-93",7),
("Amanda","2659.234","018.509.056-45",8),
("Thiago","2659.564","019.509.056-57",9),
("Anderlan","2659.56","020.509.056-64",10);

ALTER TABLE funcionario
MODIFY COLUMN cpf VARCHAR(25);
SHOW TABLES;

SELECT 
nome,
COUNT(nome) qt_nome
FROM funcionario
GROUP BY nome;

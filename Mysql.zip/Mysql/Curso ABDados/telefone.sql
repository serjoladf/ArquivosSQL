SELECT *FROM empresa.telefone;

INSERT INTO telefone(ddd,telefone)
values
("076","83642-2423"),
("041","79262-9795"),
("081","98866-3143"),
("071","99042-2423");
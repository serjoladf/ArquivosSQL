-- CREATE DATABASE senai

USE empresa;

CREATE TABLE aluno(
id int,
nome varchar(100),
data_nasc date,
cpf varchar(15)
);

select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(23,"Sergio","2024-02-23", "023.607.077-96");

select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(25,"Rodrigo","2024-02-23", "024.102.077-23");
select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(2,"Eliene","2024-02-23", "013.145.079-27"),
(3,"lek","2024-05-23", "013.122.045-13"),
(4,"Eliene","2024-06-23", "013.122.056-13");

select * from aluno;

-- ALTER TABLE aluno ADD COLUMN rg VARCHAR, ADD COLUMN salario VARCHAR DOUBLE;

CREATE TABLE professor(
id int auto_increment primary key,
cpf varchar(25) not null unique,
email varchar(200) not null,
sexo char);

select * from professor where cpf="340.987.077-12";

insert into professor(cpf,email,sexo)
values("241.187.077-32", "serjolasrg@gmail.com",'M'),
( "342.345.074-52", "serjolasrg@gmail.com",'F'),
("343.446.075-14", "serjolbbag@gmail.com",'F');

select * from professor where sexo='M';

alter table professor add column  rg int, add column salario DOUBLE;
delete from professor where id = 22;


select * from aluno;

show tables;

SHOW DATABASES;

CREATE database empresa;

DROP TABLE CARGO;

DESCRIBE aluno;

SELECT CURRENT_DATE-INTERVAL 7 DAY;
SELECT SUBDATE(CURRENT_DATE,2);


CREATE TABLE cargo(id INT AUTO_INCREMENT PRIMARY KEY, matricula INT,
descricao_cargo VARCHAR(120)
);
show databases;

INSERT INTO cargo(matricula,descricao_cargo)
VALUES(12345,"MOTORISTA"),(12346, "DENTISTA"),(12347,"PROFESSOR"),(12348,"ARTISTA"),(12349,"BIOLOGO"),(12350,"NUTRICIONISTA"),
(12351,"COZINHEIRO"),(12352,"GARCON"),(12353,"TECNOLOGO"),(12354,"MECANICO"),(12355,"VIGILANTE"),(12356,"COPEIRA");

CREATE TABLE funcionario(
id INT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(120),
rg VARCHAR(10) NOT NULL,
cpf VARCHAR(10) NOT NULL,
id_cargo int,
FOREIGN KEY(id_cargo) references cargo(id)
);

USE EMPRESA;
SELECT * FROM senai.professor;

UPDATE professor
SET email = "astucio@gmail.com"
WHERE id=4;

alter table professor add column  nome VARCHAR(30);
delete from professor where id = 22;

ALTER TABLE professor
MODIFY COLUMN id INT AUTO_INCREMENT, 
ADD PRIMARY KEY (id);

SELECT * FROM senai.professor ORDER BY salario DESC;

SELECT 
sexo,
COUNT(sexo) qt_sexo
FROM professor
GROUP BY sexo;

SELECT 
COUNT(*) sexo
FROM professor;


SELECT
CASE
WHEN sexo = 'F' THEN "FEMININO"
WHEN sexo = 'M' THEN "MASCULINO"
END sexo
FROM professor;



SELECT
id,
nome,
cpf,
email,
CASE
WHEN sexo = 'F' THEN "FEMININO"
WHEN sexo = 'M' THEN "MASCULINO"
END sexo
FROM professor;

insert into professor(cpf,email,sexo,rg,salario,nome)
values("015.187.077-77", "jane@gmail.com",'F', 2987690,1230.05,"jane"),
( "016.345.074-66", "lucas_drg@gmail.com",'M',2987690,1456.15,"Lucas"),
("017.446.075-88", "brendinha@gmail.com",'F',2987690,1430.85,"Brenda");

SELECT
f.nome,              
f.rg,
f.cpf,
c.descricao_cargo,
e.email,
t.ddd,
t.telefone
FROM funcionario f
INNER JOIN cargo c ON c.id = f.id_cargo
INNER JOIN email e ON e.id = f.id_email
INNER JOIN telefone t ON t.id = f.id_telefone;

SELECT
f.nome,              
f.rg,
f.cpf,
c.descricao_cargo,
e.email,
t.ddd,
t.telefone
FROM funcionario f
INNER JOIN cargo c ON c.id = f.id_cargo
INNER JOIN email e ON e.id = f.id_email
INNER JOIN telefone t ON t.id = f.id_telefone;

SELECT
f.nome,              
f.rg,
f.cpf,
c.descricao_cargo,
e.email,
concat("(",t.ddd,")"," ",t.telefone) As Telefone_formatado
FROM funcionario f
INNER JOIN cargo c ON c.id = f.id_cargo
INNER JOIN email e ON e.id = f.id_email
INNER JOIN telefone t ON t.id = f.id_telefone;
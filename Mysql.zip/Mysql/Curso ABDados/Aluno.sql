SELECT * FROM exercicio_abd.aluno;


INSERT INTO aluno(nome,cpf,rg,dataNasc,email,cor_de_pele,etnia,telefone,nacionalidade,naturalidade,turma_id,sexo_id,login_id) 
VALUES("marcos","013.809.055-95","2.659-8345","1982-07-09","marcolasrg@gmail.com","pardo","africana","98642-0123","brasileiro","bahia",1,1,1),
("larissa","116.234.155-96","3.660-8100","1983-08-10","larireia@gmail.com","branco","europeia","99998-0224","brasileira","goias",2,2,2),
("jano","117.345.156-97","4.670-123","1984-09-11","jano_1@gmail.com","branco","europeia","98888-0325","brasileiro","rio de Janeiro",3,1,3),
("carlos","200.811.157-98","5.680-8222","1985-10-12","carlose_deo@gmail.com","preto","africana","97777-2426","brasileiro","sao paulo",4,2,4),
("cela","100.812.158-99","6.690-8333","1986-09-03","elaba@gmail.com","pardo","europeia","99666-2427","brasileira","brasilia",5,2,5)
;
 insert into aluno(nome,cpf,rg,dataNasc,email,cor_de_pele,etnia,telefone,nacionalidade,naturalidade,turma_id,sexo_id,login_id) 
values 
("RITA CÁSSIA","005.325.435-06","67765365","1986-04-15","rita_cassia@gmail.com","branco","3351-4553","brasileira","PR",2),
("MARCO ANTÔNIO","005.624.452-04","6767634","1988-06-05","marco_antonio@gmail.com","negro","3351-4551","brasileira","DF",2,1,2),
("LUCIANA FARIAS","005.664.465-09","546887","1989-07-11","luciana_farias@gmail.com","pardo","3351-4522","brasileira","DF",2,2,1),
("IGOR NASCIMENTO","005.566.465-04","5435453","1981-02-09","igor_nascimento@gmail.com","branco","3351-4532","brasileira","GO",2,1,2),
("MATHEUS NUNES","005.326.465-07","7878954","1980-03-11","matheus_nunes@gmail.com","pardo","3351-4534","brasileira","SP",1,1,2),
("PAULO CESAR","005.365.465-09","1233246","1989-05-22","paulo_cesar@gmail.com","negro","3351-4523","brasileira","SP",3,1,3),
("ROSA NUNES","005.324.625-09","7676589","1989-06-15","rosa_nunes@gmail.com","pardo","3351-4521","brasileira","DF",4,2,5),
("RICARDO ANDRÉ","005.344.435-04","0980808","1999-08-26","ricardo_andre@gmail.com","pardo","3351-4521","brasileira","RJ",5,1,5),
("ROSANGELA MARINHO","005.656.436-05","5465342","1989-08-25","rosangela_marinho@gmail.com","pardo","3351-4500","brasileira","DF",5,2,5);


select
a.nome,
a.cpf,
c.nome_curso,
t.cod_da_turma,
t.data_inicio,
t.data_fim
from aluno a
inner join login l on l.aluno_id = a.id
inner join turma_has_aluno ta on ta.aluno_id = a.id
inner join turma t on t.id = ta.turma_id
inner join turma_has_curso tc on tc.turma_id = t.id
inner join curso c on c.id = tc.curso_id
inner join turma_has_sala ts ON t.id = ts.turma_id
inner join sala s on ts.sala_id = s.id;





select
a.nome,
a.cpf,
c.nome_curso,
t.cod_da_turma,
t.data_inicio,
t.data_fim,
count(current_date) quant_Aluno
from aluno a
inner join login l on l.aluno_id = a.id
inner join turma_has_aluno ta on ta.aluno_id = a.id
inner join turma t on t.id = ta.turma_id
inner join turma_has_curso tc on tc.turma_id = t.id
inner join curso c on c.id = tc.curso_id
inner join turma_has_sala ts ON t.id = ts.turma_id
inner join sala s on ts.sala_id = s.id
where data_inicio< current_date and data_fim > current_date
-- WHERE current_date BETWEEN t.data_inicio AND t.data_fim
group by a.nome,
a.cpf,
c.nome_curso,
t.cod_da_turma,
t.data_inicio,
t.data_fim;

update aluno
set id=7
where id=47;
-- CREATE DATABASE senai

USE senai;

CREATE TABLE aluno(
id int,
nome varchar(100),
data_nasc date,
cpf varchar(15)
);

select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(23,"Sergio","2024-02-23", "023.607.077-96");

select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(25,"Rodrigo","2024-02-23", "024.102.077-23");
select * from aluno;

insert into aluno(id,nome,data_nasc,cpf)
values(2,"Eliene","2024-02-23", "013.145.079-27"),
(3,"lek","2024-05-23", "013.122.045-13"),
(4,"Eliene","2024-06-23", "013.122.056-13");

select * from aluno;

-- ALTER TABLE aluno ADD COLUMN rg VARCHAR, ADD COLUMN salario VARCHAR DOUBLE;

CREATE TABLE professor(
id int auto_increment primary key,
cpf varchar(25) not null unique,
email varchar(200) not null,
sexo char);

select * from professor where cpf="340.987.077-12";

insert into professor(cpf,email,sexo)
values("241.187.077-32", "serjolasrg@gmail.com",'M'),
( "342.345.074-52", "serjolasrg@gmail.com",'F'),
("343.446.075-14", "serjolbbag@gmail.com",'F');

select * from professor where sexo='M';

alter table professor add column  rg int, add column salario DOUBLE;
delete from professor where id = 22;


select * from professor;

insert into professor(rg,salario)
values("12344", 12000);

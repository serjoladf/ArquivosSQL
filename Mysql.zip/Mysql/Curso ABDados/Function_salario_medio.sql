DELIMITER $$
create function salario_medio()
returns double(10,2)
deterministic
begin
declare media_salario double(10,2);
select
avg(c.salario) 
into media_salario
from cargo c;
return media_salario;
end$$
DELIMITER ;

select salario_medio();



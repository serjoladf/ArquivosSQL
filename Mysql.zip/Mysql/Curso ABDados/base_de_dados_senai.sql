create TABLE Grupo_Produto(id int primary key auto_increment, nome VARCHAR(30), descricao text);

INSERT INTO GRUPO_PRODUTO (NOME,DESCRICAO) VALUES ('GRUPO 01',NULL),('GRUPO 02',NULL),('GRUPO 03',NULL),('GRUPO 04',NULL),('GRUPO 05',NULL);

create table sub_grupo_produto(id int primary key auto_increment, id_grupo int, nome VARCHAR(30), descricao text,
foreign key (id_grupo) references grupo_produto(id));

INSERT INTO SUB_GRUPO_PRODUTO (ID_GRUPO,NOME,DESCRICAO) VALUES (1,'SUBGRUPO 1.01',NULL),(2,'SUBGRUPO 1.02',NULL),(3,'SUBGRUPO 1.03',NULL),(2,'SUBGRUPO 2.01',NULL),(1,'SUBGRUPO 2.02',NULL),(3,'SUBGRUPO 3.01',NULL);

create table Unidade_produto(id int primary key auto_increment, nome VARCHAR(15), descricao text);

INSERT INTO UNIDADE_PRODUTO (NOME,DESCRICAO) VALUES ('UND','UNIDADE'),('KG','KILO'),('CX','CAIXA'),('TON','TONELADA'),('TESTE UND','TESTE UND');

create table Produto(id int primary key auto_increment, id_sub_grupo int, id_unidade int, gtin char(15), nome_produto varchar(100), descricao text, descricao_Pdv Varchar(30), valor_compra float(11,2), valor_venda float(11,2), quant_estoque float(11,2), estoque_Min float(11,2), estoque_Max float(11,2), excluido char(1), data_cadastro date,
foreign key (id_sub_grupo) references sub_grupo_produto(id),
foreign key (id_unidade) references unidade_produto(id));

INSERT INTO PRODUTO(ID_SUB_GRUPO,ID_UNIDADE,GTIN,NOME_PRODUTO,DESCRICAO,DESCRICAO_PDV,VALOR_COMPRA,VALOR_VENDA,QUANT_ESTOQUE,ESTOQUE_MIN,ESTOQUE_MAX,EXCLUIDO,DATA_CADASTRO) 
VALUES (1,1,NULL,'CANETA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(3,1,NULL,'LAPIS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(2,3,NULL,'CADERNO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(2,4,NULL,'REGUA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(4,2,NULL,'CELTA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(4,1,NULL,'PALIO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP);

create table empresa(id int primary key auto_increment, empresa_id int, razao_social varchar(80), nome_fantasia varchar(100), CNPJ VARCHAR(25), inscricao_Estadual VARCHAR(30), Inscricao_municipal VARCHAR(30), matriz_filial char(01), data_cadastro date);

iNSERT INTO EMPRESA (EMPRESA_ID,RAZAO_SOCIAL,NOME_FANTASIA,CNPJ,INSCRICAO_ESTADUAL,INSCRICAO_MUNICIPAL,MATRIZ_FILIAL,DATA_CADASTRO) 
VALUES
(1,'SERV NACL DE APRENDIZAGEM INDUSTRIAL - DEPART REGIONAL DO DISTRITO FEDERAL','SENAI DR/DF','03806360000173',NULL,NULL,NULL,CURRENT_TIMESTAMP),
(2,'VALOR DISTRIBUIÇAO LTDA','VALOR DISTRIBUIDORA','49007123000123',NULL,NULL,NULL,CURRENT_TIMESTAMP),
(3,'SID - DISTRIBUIDORA DE ALIMENTOS LTDA ','SID','01736260000173',NULL,NULL,NULL,CURRENT_TIMESTAMP),
(4,'ALVO DISRIBUIDORA DE ALIMENTOS E CESTAS','ALVO DISTRIBUIDORA','078213400000173',NULL,NULL,NULL,CURRENT_TIMESTAMP),
(5,'SUPREMA E ESTRELA DISTRIBUICAO','SUPREMA','01300200000102',NULL,NULL,NULL,CURRENT_TIMESTAMP);

create table Convenio( id int primary key auto_increment, id_Empresa int,
nome VARCHAR(1000), descricao text, desconto double, data_Vencimento date, 
endereco varchar(250), contato varchar(30), telefone varchar(10), Excluido char(1), data_Cadastro date,
foreign key (id_Empresa) references empresa(id));

INSERT INTO CONVENIO(ID_EMPRESA,NOME,DESCRICAO,DESCONTO,DATA_VENCIMENTO,ENDERECO,CONTATO,TELEFONE,EXCLUIDO,DATA_CADASTRO)
VALUES (1,'COCA COLA',NULL,20.00,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(2,'UNILEVERL',NULL,20.00,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(3,'PARATI',NULL,20.00,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP),
(4,'ARROZ CAMIL',NULL,20.00,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP);

create table setor(id int primary key auto_increment, empresa_id int, nome varchar(20), descricao text,
foreign key (empresa_id) references empresa(id));

INSERT INTO SETOR (EMPRESA_ID,NOME,DESCRICAO) VALUES (1,'INFORMATICA',NULL),(2,'VENDAS','SETOR DE VENDAS'),(3,'RECURSOS HUMANOS','RECURSOS HUMANOS'),
(4,'ALIMENTOS',NULL),(5,'LIMPEZA',NULL);

create table cargo(id int primary key auto_increment, nome_cargo varchar(20), descricao text , salario double(11,2));

INSERT INTO CARGO(NOME_CARGO,DESCRICAO,SALARIO) VALUES 
('ASSISTENTE TECNICO','ASSISITENTE DE SISTEMAS',1212.00),
('ANALISTA','ANALISTA DE SISTEMAS',8000.00),
('PROGRAMADOR','AJUDA O ANALISTA',5500.00),
('DBA','ADM DE BANCO DE DADOS',6000.00),
('TÉC DE INFORMÁTICA','AUXILIAR DE PROGRAMADOR',1900.00),
('ANALISTA DE REDES','ANALISTA DE REDES',2000.00),
('ESENVOLVEDOR JAVA','AJUDA O ANALISTA',3800.00),
('ESENVOLVEDOR PYTHON','ANALISTA DE DADOS',3000.00),
('WEB DESIGNER ','DESENVOVEDOR E SITES',1100.00),
('TÉCNICO','ADMINISTRATIVO',2500.00);

create table tipo_colaborador(id int primary key auto_increment, nome varchar(20), descricao text);

INSERT INTO TIPO_COLABORADOR (NOME,DESCRICAO) VALUES ('EMPREGADO',NULL),
('REPRESENTANTE','REPRESENTANTE DA EMPRESA'),('VEDEDOR','REPRESENTANTE MASTER'),
('RCA','REPRESENTANTE DE VENDAS'),('AUXILIAR','AUX MASTER');

create table nivel_Formacao(id int primary key auto_increment, nome varchar(20), descricao text);

INSERT INTO NIVEL_FORMACAO (NOME,DESCRICAO) VALUES ('MESTRADO',NULL),('ENSINO MEDIO',NULL),('ENSINO FUNDAMENTAL',NULL),
('DOTOURADO',NULL);

create table funcao(id int primary key auto_increment, descricao_menu text, imagem_menu varchar(30), metodo varchar(30));

INSERT INTO FUNCAO (DESCRICAO_MENU, IMAGEM_MENU, METODO) VALUES ('Cadastro de Usuários', 'cad_usuario.jpg', 'adicionarUsuario'),
('Consulta de Produtos', 'consulta_produto.jpg', 'consultarProdutos'),('Relatório de Vendas', 'relatorio_vendas.jpg', 'gerarRelatorioVendas'),
('Configurações do Sistema', 'config_sistema.jpg', 'acessarConfiguracoes'),('Gestão de Estoque', 'gestao_estoque.jpg', 'gerenciarEstoque'),
('Suporte Técnico', 'suporte_tecnico.jpg', 'acessarSuporte'),('Cadastro de Fornecedores', 'cad_fornecedor.jpg', 'adicionarFornecedor'),
('Agenda de Compromissos', 'agenda_compromissos.jpg', 'gerenciarAgenda'),('Notificações do Sistema', 'notificacoes_sistema.jpg', 'verNotificacoes'),
('Gerenciamento de Permissões', 'ger_permissoes.jpg', 'editarPermissoes');

create table tipo_Email(id int primary key auto_increment, nome varchar(20), descricao text);

INSERT INTO TIPO_EMAIL (NOME,DESCRICAO) VALUES ('PESSOAL',NULL),('EMPRESA',NULL),('RECURSOS',NULL);

create table pais(id int primary key auto_increment, codigo int, nome_pais varchar(100), sigla2 char(2), sigla3 char(3));

INSERT INTO PAIS (CODIGO,NOME_PAIS,SIGLA2,SIGLA3) VALUES (1,'BRASIL','BR','BRA'),(2,'ESTADOS UNIDOS','EU','EUA'),(3,'ANGOLA','AN','ANG');

create table tipo_telefone(id int primary key auto_increment, nome varchar(100), descricao text);

INSERT INTO TIPO_TELEFONE (NOME,DESCRICAO) VALUES ('RESIDENCIAL',NULL),('PESSOAL',NULL),('EMPRESARIA',NULL),('HOTEL',NULL);

create table banco(id int primary key auto_increment, codigo int, nome_banco varchar(100), url varchar(200));

INSERT INTO BANCO (CODIGO,NOME_BANCO,URL) VALUES (1,'BANCO DO BRASIL','BB.COM'),(237,'BRADESCO','BRADESCO.COM'),(555,'ITAU','ITAU.COM');

create table tipo_Endereco(id int primary key auto_increment, nome varchar(20), descricao text);

INSERT INTO TIPO_ENDERECO (NOME,DESCRICAO) VALUES ('RESIDENCIAL','Endereço moradia.'),('TRABALHO','Endereço do local de trabalho');

create  table tipo_relacionamento(id int primary key auto_increment, nome varchar(30), descricao text);

INSERT INTO TIPO_RELACIONAMENTO (NOME,DESCRICAO) VALUES ('FILHO',NULL),('PAI',NULL),('FORNECEDOR',NULL),('CLIENTE',NULL),('COMPRADOR',NULL);

create table CFOP(id int primary key auto_increment, CFOP int, descricao text, aplicacao text);

INSERT INTO CFOP (CFOP,DESCRICAO,APLICACAO) VALUES (1000,'ENTRADAS OU AQUISIÇÕES DE SERVIÇOS DO ESTADO','Classificam-se, neste grupo, as operações ou prestações em que o estabelecimento remetente esteja localizado na mesma unidade da Federação do destinatário'),(1100,'COMPRAS PARA INDUSTRIALIZAÇÃO, PRODUÇÃO RURAL, COMERCIALIZAÇÃO OU PRESTAÇÃO DE SERVIÇOS','(NR Ajuste SINIEF 05/2005) (DECRETO Nº 28.868, DE 31/01/2006)\r\n\r\n(Dec. 28.868/2006 – Efeitos a partir de 01/01/2006, ficando facultada ao contribuinte a sua adoção para fatos geradores ocorridos no período de 01 de novembro a 31 de dezembro de 2005)'),(1101,'Compra para industrialização ou produção rural (NR Ajuste SINIEF 05/2005) (Decreto 28.868/2006)','Compra de mercadoria a ser utilizada em processo de industrialização ou produção rural, bem como a entrada de mercadoria em estabelecimento industrial ou produtor rural de cooperativa recebida de seus cooperados ou de estabelecimento de outra cooperativa.\r\n\r\n(DECRETO Nº 28.868, DE 31/01/2006-– Efeitos a partir de 01/01/2006, ficando facultada ao contribuinte a sua adoção para fatos geradores ocorridos no período de 01 de novembro a 31 de dezembro de 2005).'),(1102,'Compra para comercialização','Classificam-se neste código as compras de mercadorias a serem comercializadas. Também serão classificadas neste código as entradas de mercadorias em estabelecimento comercial de cooperativa recebidas de seus cooperados ou de estabelecimento de outra cooperativa.');

create table operadora_cartao(id int primary key auto_increment, bandeira varchar(30), nome varchar(100));

INSERT INTO OPERADORA_CARTAO (BANDEIRA,NOME) VALUES ('VISA','0VISA'),('MASTERCARD','0MASTERCARD');

create  table  SITUACAO_FOR_CLI (id int primary key auto_increment, nome varchar(30), descricao text);

INSERT INTO SITUACAO_FOR_CLI (NOME,DESCRICAO) VALUES ('NORMAL',NULL),('DEVEDOR',NULL),('OUTRO',NULL),('DEVEDOR','BLOQUEADO'),('NORMAL','LIBERADO');

create table indice_economico(id int primary key auto_increment,pais_id int, sigla varchar(30),nome varchar(100), descricao text,
foreign key (pais_id) references pais(id));

INSERT INTO INDICE_ECONOMICO (PAIS_ID,SIGLA,NOME,DESCRICAO) VALUES (1,'IPCA','INDICE DE PRECOS CONSUMIDOR AMPLO',NULL);

create table estado(id int primary key auto_increment, pais_id int, sigla char(2), nome varchar(50), codigo_IBGE int,
foreign key (pais_id) references pais(id));

INSERT INTO ESTADO (PAIS_ID,SIGLA,NOME,CODIGO_IBGE) VALUES (1,'DF','DISTRITO FEDERAL',53),(1,'CE','CEARA',19),(1,'BA','BAHIA',21),(2,'NY','NEW YORK',NULL);

create table cidade(id int primary key auto_increment, estado_id int, nome varchar(100), codigo_IBGE int,
foreign key (estado_id) references estado(id));

INSERT INTO CIDADE (ESTADO_ID,NOME,CODIGO_IBGE) VALUES (1,'BRASILIA',53123),(2,'BAHIA',10242),(1,'SOBRADINHO',53411),(2,'CAMACARI',19345);

create table cep(id int primary key auto_increment,cidade_id int, cep varchar(20), logradouro varchar(100), bairro varchar(100),
foreign key (cidade_id) references cidade(id));

INSERT INTO CEP (CIDADE_ID,CEP,LOGRADOURO,BAIRRO) VALUES (1,'60763560','RUA 107','CENTRO'),(2,'60763561','RUA 108','CENTRO'),(3,'60763501','RUA 10','SUBURBIO');

create table agencia_Banco(id int primary key auto_increment, cep_id int, banco_id int,codigo int, nome varchar(100),
endereco varchar(120), telefone varchar(15), gerente varchar(30), contato varchar(30), obs text,
foreign key (cep_id) references cep(id),
foreign key (banco_id) references banco(id));

INSERT INTO AGENCIA_BANCO (CEP_ID,BANCO_ID,CODIGO,NOME,ENDERECO,TELEFONE,GERENTE,CONTATO,OBS) VALUES 
(1,1,1522,'AG AGUAS CLARAS',NULL,NULL,'NUNES',NULL,NULL),(1,2,666,'666','RUA 107','666','666','666','666'),(1,1,77,'77','RUA 107','77','77','77','77'),(1,1,66,'66','66','66','66','66','66'),(1,2,987,'987','RUA 107','987','987','987','987'),(1,2,789789,'789789','RUA 107','789789','789789','789789','789789'),(1,2,8787,'AGENCIA 87879','RUA 107','87878787','GERENTE 8787','CONTATO 8787','8787'),(1,3,8798,'ITAU555','RUA 107','ITAU555','ITAU555','ITAU555','ITAU555'),(1,2,474747,'47','RUA 107','47','47','47','47'),(1,1,445566,'445566','RUA 107','445566','445566','445566','445566'),
(1,3,9966,'9966','RUA 107','9966','9966','9966','9966'),(1,3,555888,'555888','RUA 107','555888','555888','555888','555888');

create  table  TIPO_FORNECEDOR(id int primary key auto_increment, nome varchar(30), descricao text);

INSERT INTO TIPO_FORNECEDOR(NOME,DESCRICAO) VALUES ('FORNECEDOR',NULL),('FORNECEDOR','ALIMENTOS'),
('FORNECEDOR','M. LIMPEZA'),('FORNECEDOR','P. BELEZA');

create table fornecedor(id int primary key auto_increment, tipo_fornecedor_id int, situacao_for_cli_id int,
id_empresa int, nome varchar(150), CPF_CNPJ VARCHAR(25), RG VARCHAR(20), ORGAO_RG VARCHAR (10), inscricao_Estadual VARCHAR(20),
Inscricao_municipal VARCHAR(20), desde date, tipo_pessoa char(1), excluido char(1), data_cadastro date,
foreign key (id_empresa) references empresa(id),
foreign key (tipo_fornecedor_id) references fornecedor(id),
foreign key (situacao_for_cli_id) references situacao_for_cli(id));

Insert into fornecedor(SITUACAO_FOR_CLI_ID,TIPO_FORNECEDOR_ID,ID_EMPRESA,NOME,CPF_CNPJ,RG,ORGAO_RG,INSCRICAO_ESTADUAL,INSCRICAO_MUNICIPAL,DESDE,
TIPO_PESSOA,EXCLUIDO,DATA_CADASTRO)
values(1,1,1,'JOÃO','254543543100','2567893','ssp/DF','0732336300110','0732336300110',null,'1','1','2022-03-01'),
(3,2,3,'ANDRE','46365363490','34343344','ssp/RS','0812436300111','0812436300111',null,'1','1','2020-03-02'),
(2,3,4,'MARIA','01360905587','4123456','ssp/SP','0922236300112','0922236300112',null,'1','1','2010-05-22'),
(4,4,2,'ANTONIO','01516723457','100123245','ssp/RJ','0844436300113','0844436300113',null,'1','1','2019-01-12'),
(3,5,4,'NEGEU','12324310035','3003045344','ssp/BA','1255536300114','1255536300114',null,'1','1','2017-03-06');


Create table fornecedor_produto(id int primary key auto_increment, fornecedor_id int, produto_id int,
foreign key (fornecedor_id) references fornecedor(id),
foreign key (produto_id) references produto(id));

insert  into fornecedor_produto(fornecedor_id,produto_id) VALUES(1,1),(2,2),(3,4),(4,3),(5,4);

create table papel(id int primary key auto_increment, nome varchar(20), descricao text);

INSERT INTO PAPEL (NOME,DESCRICAO) VALUES ('ADM','ADMINISTRADO'),('USER','USUARIO'),('TESTE','TESTE');

create table papel_funcao(id int primary key auto_increment, funcao_id int, papel_id int, pode_Consultar char(1), pode_Inserir char(1),pode_Alterar char(1), pode_Excluir char(1),
foreign key (papel_id) references papel(id),
foreign key (funcao_id) references funcao(id));

INSERT INTO PAPEL_FUNCAO(FUNCAO_ID, PAPEL_ID, PODE_CONSULTAR, PODE_INSERIR, PODE_ALTERAR, PODE_EXCLUIR)
VALUES
(1,1,'S','N','N','N'),(2,2,'S','S','N','S'),(3,3,'N','S','N','N'),(1,3,'N','N','N','S'),(2,3,'S','N','N','S');


create table cliente(id int primary key auto_increment, situacao_for_cli_id int, id_empresa int,
nome varchar(150), CPF_CNPJ VARCHAR(25), RG VARCHAR(20), ORG_RG VARCHAR (10), inscricao_Estadual VARCHAR(30),
Inscricao_municipal VARCHAR(30), desde date, tipo_pessoa char(1),EXCLUIDO CHAR(1), data_cadastro date,
foreign key (id_empresa) references empresa(id),
foreign key (situacao_for_cli_id) references situacao_for_cli(id));

INSERT INTO CLIENTE (SITUACAO_FOR_CLI_ID,ID_EMPRESA,NOME,CPF_CNPJ,RG,ORG_RG,INSCRICAO_ESTADUAL,INSCRICAO_MUNICIPAL,DESDE,TIPO_PESSOA,EXCLUIDO,DATA_CADASTRO)
VALUES (1,1,'CLIENTE 01','0711955500112','0711955500112','SSP-DF',NULL,'','2010-06-01','J','N',CURRENT_TIMESTAMP),
(2,2,'CLIENTE 02','0112355500109','0112355500109','SSP-DF',NULL,'','2011-06-04','F','N',CURRENT_TIMESTAMP),
(4,3,'CLIENTE 03','1311966600117','1311966600117','SSP-BA',NULL,'','2012-08-21','J','N',CURRENT_TIMESTAMP),
(3,4,'CLIENTE 04','0811233500112','0811233500112','SSP-RJ',NULL,'','2013-07-11','F','N',CURRENT_TIMESTAMP),
(4,5,'CLIENTE 05','0911911100112','0911911100112','SSP-SP',NULL,'','2014-10-09','J','N',CURRENT_TIMESTAMP);

create TABLE empresa_Produto(id int primary key auto_increment, empresa_id int,  produto_id int,
foreign key (empresa_id) references empresa(id),
foreign key (produto_id) references produto(id));

INSERT INTO EMPRESA_PRODUTO(EMPRESA_ID, PRODUTO_ID) VALUES (1,2),(2,1),(3,2),(4,1),(4,5),(2,2),(3,4),(5,2);

create table colaborador(id int primary key auto_increment, nivel_formacao_id int, tipo_colaborador_id int, cargo_id int, id_setor int,
 nome_colaborador varchar(140), cpf varchar(20), rg varchar(20), orgao_rg varchar(20), dataNascimento date, tipo_sanguineo varchar(25),foto_34 varchar(20), excluido char(1) ,data_cadastro date,
foreign key (nivel_formacao_id) references nivel_formacao(id),
foreign key (tipo_colaborador_id) references tipo_colaborador(id),
foreign key (cargo_id) references cargo(id),
foreign key (id_setor) references setor(id));

INSERT INTO COLABORADOR (NIVEL_FORMACAO_ID,TIPO_COLABORADOR_ID,CARGO_ID,ID_SETOR,NOME_COLABORADOR,CPF,RG,ORGAO_RG,DATANASCIMENTO,TIPO_SANGUINEO,FOTO_34,EXCLUIDO,DATA_CADASTRO) VALUES
 (1,1,1,1,'ALBERT','12345678910','23456780','SSP-CE','1977-04-22','A+',NULL,'N',CURRENT_TIMESTAMP),
(2,3,2,2,'MARCOS','12033367890','34567820','SSP-BA','1989-08-02','O+',NULL,'S',CURRENT_TIMESTAMP),
(3,2,3,4,'LEMOS','01234522209','23469500','SSP-DF','1992-06-12','AB',NULL,'N',CURRENT_TIMESTAMP),
(1,2,4,5,'DIANA','02304446782','191314657','SSP-SP','1969-04-01','B',NULL,'S',CURRENT_TIMESTAMP),
(4,3,5,3,'ANISIO','01360905596','180891234','SSP-RJ','1967-05-30','A+',NULL,'N',CURRENT_TIMESTAMP);
 
 create table usuario(id int primary key auto_increment, papel_id int, colaborador_id int, login varchar(50), senha varchar(30),
data_cadastro date,
foreign key (papel_id) references papel(id),
foreign key (colaborador_id) references colaborador(id));

INSERT INTO USUARIO (PAPEL_ID,COLABORADOR_ID,LOGIN,SENHA,DATA_CADASTRO) VALUES (1,1,'ALBERT','123145',NULL),(2,2,'MARCOS','100023',NULL),
(3,3,'LEMOS','1234523',NULL),(1,4,'DIANA','123145',NULL),(3,5,'ANISIO','1JJJ023',NULL);

create table endereco(id int primary key auto_increment, empresa_id int, colaborador_id int, fornecedor_id int, cliente_id int, 
tipo_endereco_id int, cep_id int, logradouro varchar(100), numero int, complemento varchar(50), bairro varchar(50), dono char(1),
foreign key (empresa_id) references empresa(id),
foreign key (colaborador_id) references colaborador(id),
foreign key (fornecedor_id) references fornecedor(id),
foreign key (cliente_id) references cliente(id),
foreign key (cep_id) references cep(id),
foreign key (tipo_endereco_id) references tipo_endereco(id));


insert into endereco(EMPRESA_ID,COLABORADOR_ID,FORNECEDOR_ID,CLIENTE_ID,TIPO_ENDERECO_ID,CEP_ID,LOGRADOURO,NUMERO,COMPLEMENTO,BAIRRO,DONO)
values (1,1,2,1,1,1,'QUADRA 104','23','SETOR COMERCIAL SUL','TAGUATINGA','C'),
(2,2,4,1,2,1,'RUA NORTE','14','SETOR COMERCIAL NORTE','TAGUATINGA','C'),
(4,3,5,1,2,1,'QUADRA 21','105','SETOR HOTELEIRO','ASA NORTE','C'),
(3,4,2,1,1,1,'QUADRA 111','306','SQS','ASA SUL','C'),
(5,5,3,1,1,1,'RUA 07','27','SETOR DE CHACARA','SAMAMBAIA','C');

create table contato(id int primary key auto_increment, EMPRESA_ID int, COLABORADOR_ID int,CLIENTE_ID int,FORNECEDOR_ID int, NOME_CONTATO varchar(120) ,DONO char(1),
foreign key (empresa_id) references empresa(id),
foreign key (colaborador_id) references colaborador(id),
foreign key (cliente_id) references cliente(id),
foreign key (fornecedor_id) references fornecedor(id));

insert into CONTATO(EMPRESA_ID,COLABORADOR_ID,CLIENTE_ID,FORNECEDOR_ID,NOME_CONTATO,DONO) 
VALUES 
(1,1,1,2,'MAURICIO',NULL),
(2,2,2,3,'NUNES',NULL),
(3,3,3,1,'PANDORA',NULL),
(4,4,4,4,'MACEDO',NULL),
(5,5,5,5,'PAULO',NULL);


create table contato_Email(id int primary key auto_increment, tipo_email_id int,contato_id int, email varchar(100),
foreign key (tipo_email_id) references tipo_Email(id),
foreign key (contato_id) references contato(id));

INSERT INTO CONTATO_EMAIL (TIPO_EMAIL_ID,CONTATO_ID,EMAIL) VALUES (1,1,'adm@senai.com'),(2,2,'adm@empresa.com'),
(3,3,'adm@empresa2.com');

create table contato_telefone(id int primary key auto_increment, tipo_telefone_id int, contato_id int, telefone varchar(20),
foreign key (tipo_telefone_id) references tipo_telefone(id),
foreign key (contato_id) references contato(id));

INSERT INTO CONTATO_TELEFONE (TIPO_TELEFONE_ID,CONTATO_ID,TELEFONE) VALUES 
(1,1,'6154875487'), 
(2,2,'6134872543'),
(3,3,'614567487'),
(4,2,'61234175487'),
(2,3,'61230075487');

create table colaborador_relacionamento(id int primary key auto_increment, tipo_relacionamento_id  int, colaborador_id int, nome varchar(50),
foreign key (tipo_relacionamento_id) references tipo_relacionamento(id),
foreign key (colaborador_id) references colaborador(id));

INSERT INTO colaborador_relacionamento( tipo_relacionamento_id, colaborador_id, nome) VALUES (1,1,'santana'),
(1,1,'cliente'),
(2,3,'amigo'),
(3,4,'cliente'),
(4,2,'fornecedor'),
(5,5,'fornecedor');
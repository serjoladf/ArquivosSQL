CREATE DATABASE exSegunda;

USE exSegunda;

create TABLE Grupo_Produto(id int primary key auto_increment, nome VARCHAR(30), descricao text);

create table sub_grupo_produto(id int primary key auto_increment, id_grupo int, nome VARCHAR(30), descricao text,
foreign key (id_grupo) references grupo_produto(id));

create table Unidade_produto(id int primary key auto_increment, nome VARCHAR(15), descricao text);


create table Produto(id int primary key auto_increment, id_sub_grupo int, id_unidade int, gtin char(15), nome_produto varchar(100), descricao text, descricao_Pdv Varchar(30), valor_compra float(11,2), valor_venda float(11,2), quant_estoque float(11,2), estoque_Min float(11,2), estoque_Max float(11,2), excluido char(1), data_cadastro date,
foreign key (id_sub_grupo) references sub_grupo_produto(id),
foreign key (id_unidade) references unidade_produto(id));

create table fornecedor_produto(id int primary key auto_increment, fornecedor_id int, produto_id int);

-- create table C int primary key auto_increment, nome varchar(20), descricao text);

create table fornecedor(id int primary key auto_increment, tipo_fornecedor_id int, situacao_for_cli_id int,
id_empresa int, nome varchar(150), CPF_CNPJ VARCHAR(25), RG VARCHAR(20), ORG_RG VARCHAR (10), inscricao_Estadual VARCHAR(20),
Inscricao_municipal VARCHAR(20), desde date, tipo_pessoa char(1), excluido char(1), data_cadastro date,
foreign key (id_empresa) references empresa(id),
foreign key (tipo_fornecedor_id) references fornecedor(id),
foreign key (situacao_for_cli_id) references situacao_for_cli(id));

create table papel(id int primary key auto_increment, nome varchar(20), descricao text);
create table funcao(id int primary key auto_increment, descricao_menu text, imagem_menu varchar(30), metodo varchar(30));
create table papel_funcao(id int primary key auto_increment, funcao_id int, papel_id int, pode_Consultar char(1), pode_Inserir char(1),pode_Alterar char(1), pode_Excluir char(1),
foreign key (papel_id) references papel(id),
foreign key (funcao_id) references funcao(id));

create TABLE empresa_Produto(id int primary key auto_increment, empresa_id int,  produto_id int,
foreign key (empresa_id) references empresa(id),
foreign key (produto_id) references produto(id));

create table empresa(id int primary key auto_increment, empresa_id int, razao_social varchar(80), nome_fantasia varchar(100), CNPJ VARCHAR(25), inscricao_Estadual VARCHAR(30), Inscricao_municipal VARCHAR(30), matriz_filial char(01), data_cadastro date);
create table Convenio( id int primary key auto_increment, id_Empresa int,
 nome VARCHAR(1000), descricao text, desconto double, data_Vencimento date, 
 endereco varchar(250), contato varchar(30), telefone varchar(10), Excluido char(1), data_Cadastro date,
foreign key (id_Empresa) references empresa(id));

create table setor(id int primary key auto_increment, empresa_id int, nome varchar(20), descricao text,
foreign key (empresa_id) references empresa(id));

create table situacao_for_cli(id int primary key auto_increment,nome varchar(40), descricao text);

create table cliente(id int primary key auto_increment, situacao_for_cli_id int, id_empresa int,
 nome varchar(150), CPF_CNPJ VARCHAR(25), RG VARCHAR(20), ORG_RG VARCHAR (10), inscricao_Estadual VARCHAR(30),
 Inscricao_municipal VARCHAR(30), desde date, tipo_pessoa char(1), data_cadastro date,
foreign key (id_empresa) references empresa(id),
foreign key (situacao_for_cli_id) references situacao_for_cli(id));

create table estado(id int primary key auto_increment, pais_id int, sigla char(2), nome varchar(50), codigo_IBGE int,
foreign key (pais_id) references pais(id));

create table cidade(id int primary key auto_increment, estado_id int, nome varchar(100), codigo_IBGE int,
foreign key (estado_id) references estado(id));

create table pais(id int primary key auto_increment, codigo int, nome varchar(100), sigla2 char(2), sigla char(3));

create table indice_economico(id int primary key auto_increment,pais_id int, sigla varchar(30),nome varchar(100), descricao text,
foreign key (pais_id) references pais(id));

drop table cep;

drop table cidade;

drop table endereco;

drop table agencia_banco;

create table cep(id int primary key auto_increment,cidade_id int, cep varchar(20), logradouro varchar(100), bairro varchar(100),
foreign key (cidade_id) references cidade(id));

create table funcao(id int primary key auto_increment, descricao_menu text, imagem_menu varchar(30), metodo varchar(30));

create table tipo_Email(id int primary key auto_increment, nome varchar(20), descricao text);

create table contato_Email(id int primary key auto_increment, tipo_email_id int,contato_id int, email varchar(100),
foreign key (tipo_email_id) references tipo_Email(id),
foreign key (contato_id) references contato(id));

create table contato(id int primary key auto_increment, empresa_id int, colaborador_id int,cliente_id int,fornecedor_id int, nome varchar(100), dono char(1));

create table tipo_Endereco(id int primary key auto_increment, nome varchar(20), descricao text);


create table endereco(id int primary key auto_increment, empresa_id int, colaborador_id int, fornecedor_id int, cliente_id int, 
tipo_endereco_id int, cep_id int, logradouro varchar(100), coplemento varchar(50), bairro varchar(50), dono char(1),
foreign key (empresa_id) references empresa(id),
foreign key (colaborador_id) references colaborador(id),
foreign key (fornecedor_id) references fornecedor(id),
foreign key (cliente_id) references cliente(id),
foreign key (cep_id) references cep(id),
foreign key (tipo_endereco_id) references tipo_endereco(id));

create table contato(id int primary key auto_increment, empresa_id int, colaborador_id int,cliente_id int,fornecedor_id int,
nome varchar(100), dono char(1),
foreign key (empresa_id) references empresa(id),
foreign key (colaborador_id) references colaborador(id),
foreign key (fornecedor_id) references fornecedor(id),
foreign key (cliente_id) references cliente(id));

create table tipo_Endereco(id int primary key auto_increment, nome varchar(20), descricao text);

create  table tipo_relacionamento(id int primary key auto_increment, nome varchar(30), descricao text);

create table colaborador_relacionamento(id int primary key auto_increment, tipo_relacionamento_id  int, colaborador_id int, nome varchar(50),
foreign key (tipo_relacionamento_id) references tipo_relacionamento(id),
foreign key (colaborador_id) references colaborador(id));

create table banco(id int primary key auto_increment, codigo int, nome varchar(100), url varchar(200));

create table agencia_Banco(id int primary key auto_increment, cep_id int, banco_id int,condigo int, nome varchar(100),
enderece varchar(120), telefone varchar(15), gerente varchar(30), contato varchar(30), obs text,
foreign key (cep_id) references cep(id),
foreign key (banco_id) references banco(id));

create table tipo_telefone(id int primary key auto_increment, nome varchar(100), descricao text);

create table contato_telefone(id int primary key auto_increment, tipo_telefone_id int, contato_id int, telefone varchar(20),
foreign key (tipo_telefone_id) references tipo_telefone(id),
foreign key (contato_id) references contato(id));

create table cargo(id int primary key auto_increment, nome varchar(20), descricao text , salario double(11,2));

create table tipo_colaborador(id int primary key auto_increment, nome varchar(20), descricao text);

create table nivel_Formacao(id int primary key auto_increment, nome varchar(20), descricao text);

create table colaborador(id int primary key auto_increment, nivel_formacao_id int, tipo_colaborador_id int, cargo_id int, id_setor int,
 nome varchar(140), cpf varchar(20), rg varchar(20), orgao_rg varchar(20), dataNascimento date, tipo_sanguineo varchar(25), excluido char(1) ,data_cadastro date,
foreign key (nivel_formacao_id) references nivel_formacao(id),
foreign key (tipo_colaborador_id) references tipo_colaborador(id),
foreign key (cargo_id) references cargo(id),
foreign key (id_setor) references setor(id));

create table usuario(id int primary key auto_increment, papel_id int, colaborador_id int, login varchar(50), senha varchar(30),
data_cadastro date,
foreign key (papel_id) references papel(id),
foreign key (colaborador_id) references colaborador(id));

create table indice_economico(id int primary key auto_increment,pais_id int, sigla varchar(30),nome varchar(100), descricao text);

create table CFOP(id int primary key auto_increment, CFOP int, descricao text, aplicacao text);

create table operadora_cartao(id int primary key auto_increment, bandeira varchar(30), nome varchar(100));

create table tipo_telefone(id int primary key auto_increment, nome varchar(100), descricao text);

create table tipo_fornecedor(id int primary key auto_increment, nome varchar(100), descricao text);


create table empresa(id int primary key auto_increment, empresa_id int, razao_social varchar(80), nome_fantasia varchar(100), CNPJ VARCHAR(25), inscricao_Estadual VARCHAR(30), Inscricao_municipal VARCHAR(30), matriz_filial char(01), data_cadastro date);
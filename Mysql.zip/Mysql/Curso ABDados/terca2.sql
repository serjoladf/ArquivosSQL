USE empresa;

CREATE TABLE cargo(id INT AUTO_INCREMENT PRIMARY KEY, matricula INT,
descricao_cargo VARCHAR(120)
);
show tables;

INSERT INTO cargo(matricula,descricao_cargo)
VALUES(12345,"MOTORISTA"),(12346, "DENTISTA"),(12347,"PROFESSOR"),(12348,"ARTISTA"),(12349,"BIOLOGO"),(12350,"NUTRICIONISTA"),
(12351,"COZINHEIRO"),(12352,"GARCON"),(12353,"TECNOLOGO"),(12354,"MECANICO"),(12355,"VIGILANTE"),(12356,"COPEIRA");

CREATE TABLE funcionario(
id INT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(120),
rg VARCHAR(10) NOT NULL,
cpf VARCHAR(10) NOT NULL,
id_cargo int,
FOREIGN KEY(id_cargo) references cargo(id)
);

SELECT*FROM funcionario as fun
INNER JOIN cargo cg ON cg.id = fun.id_cargo;

SELECT*FROM funcionario as fun 
RIGHT JOIN cargo cg ON cg.id = fun.id_cargo;

SELECT*FROM funcionario as fun
LEFT JOIN cargo cg ON cg.id = fun.id_cargo;

SELECT*FROM funcionario as fun
RIGHT JOIN cargo cg ON cg.id = fun.id_cargo
WHERE fun.nome is null and fun.rg is null and fun.cpf is null;

SELECT*FROM funcionario;

SELECT 
COUNT(cg.descricao_cargo) AS qt_cargo,
cg.descricao_cargo
FROM funcionario as fun
INNER JOIN cargo as cg ON cg.id = fun.id_cargo
GROUP BY cg.descricao_cargo;

SELECT 
COUNT(cg.descricao_cargo) AS qt_cargo,
cg.descricao_cargo
FROM funcionario as fun
INNER JOIN cargo as cg ON cg.id = fun.id_cargo
GROUP BY cg.descricao_cargo;

SELECT 
COUNT(cg.descricao_cargo) AS qt_cargo,
cg.descricao_cargo
FROM funcionario as fun
INNER JOIN cargo as cg ON cg.id = fun.id_cargo
GROUP BY COUNT(cg.descricao_cargo) DESC;

CREATE TABLE telefone(
id INT AUTO_INCREMENT PRIMARY KEY,
ddd VARCHAR(5),
telefone  VARCHAR(15)
);

CREATE TABLE email(
id INT AUTO_INCREMENT PRIMARY KEY,
email  VARCHAR(50),
email_2  VARCHAR(50)
);

SHOW TABLES;

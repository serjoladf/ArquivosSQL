
 
 
SELECT  f.nome_fornecedor, p.nome_produto, p.valor
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE p.id = ANY
(SELECT id
 FROM pedidos
 WHERE not valor > 2.60);
 
 SELECT * FROM quarta.produtos;

 
SELECT  f.nome_fornecedor, p.quantidade, p.nome_produto, p.valor
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE  nome_Produto = ANY
(SELECT nome_Produto
 FROM produtos p
 WHERE p.quantidade = 30); -- O primeiro código seleciona produtos com quantidade igual a 30.

 
 
 
SELECT
f.nome_fornecedor as Fornecedor, 
p.quantidade as Quantidade,
p.nome_produto as Produto,
p.valor as "Valor R$"
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE p.id = ANY
(SELECT id 
FROM pedidos
WHERE quantidade =30); -- O segundo código seleciona produtos que estão presentes em algum pedido.


UPDATE produtos
SET nome_produto =
    CASE
        WHEN id = 1 THEN "Feijão"
        WHEN id = 2 THEN "Arroz"
        WHEN id = 3 THEN "Macarrão"
        WHEN id = 4 THEN "Café"
        WHEN id = 5 THEN "Crema Crack"
        WHEN id = 6 THEN "Óleo"
        WHEN id = 7 THEN "Farinha"
        WHEN id = 8 THEN "Rosquinha"
        WHEN id = 9 THEN "Feijao Preto"
        WHEN id = 10 THEN "Miojo"
        ELSE nome_produto
    END;
 
 
 UPDATE produtos
SET quantidade =
    CASE
        WHEN id = 1 THEN 12
        WHEN id = 2 THEN 23
        WHEN id = 3 THEN 17
        WHEN id = 4 THEN 10
        WHEN id = 5 THEN 15
        WHEN id = 6 THEN 30
        WHEN id = 7 THEN 40
        WHEN id = 8 THEN 80
        WHEN id = 9 THEN 70
        WHEN id = 10 THEN 120
        ELSE quantidade
    END;
    
     UPDATE fornecedor
    SET nome_fornecedor =
    CASE
        WHEN id = 1 THEN "Sid"
        WHEN id = 2 THEN "Alvo"
        WHEN id = 3 THEN "Sobebe"
        WHEN id = 4 THEN "Valor Distribuição"
        WHEN id = 5 THEN "Nova amazonas"
        WHEN id = 6 THEN "Eldorado"
        WHEN id = 7 THEN "Atacadão"
        WHEN id = 8 THEN "Rio Vermelho"
        WHEN id = 9 THEN "Martins"
        WHEN id = 10 THEN "Peixoto"
        ELSE nome_fornecedor
        end;
        
        
        SELECT Nome_Fornecedor
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor < 2.60);


SELECT*
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor = 2.10);

SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND not valor < 2.60);


SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id		
= f.Id AND valor = 2.10);

SELECT  f.nome_fornecedor, p.nome_produto, p.valor
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND not valor < 2.60);

SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = ANY (SELECT id FROM pedidos WHERE quantidade = 30);
    
    
SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    quantidade = 30;

SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = ANY (SELECT id FROM pedidos WHERE quantidade = 30);
    
    
    SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = ALL (SELECT id FROM pedidos WHERE quantidade = 40);
    
    SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = SOME (SELECT id FROM pedidos WHERE NOT quantidade = 30);
    
    
    SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = SOME (SELECT id FROM pedidos WHERE quantidade = 30);
    
        SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = ALL (SELECT id FROM pedidos WHERE quantidade >= 5 AND quantidade <= 100);
    
    
    SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id IN (SELECT id FROM pedidos WHERE quantidade >= 5 AND quantidade <= 100);
    
    
        SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id
WHERE 
    p.id = ALL (SELECT id FROM pedidos WHERE quantidade = 12);
    
    
        
        SELECT
    f.nome_fornecedor as Fornecedor, 
    p.quantidade as Quantidade,
    p.nome_produto as Produto,
    p.valor as "Valor R$"
FROM 
    Fornecedor f
INNER JOIN 
    produtos p ON p.fornecedor_id = f.id

WHERE 
        p.id = all (SELECT pe.id FROM pedidos pe     group by pe.id  having count(p.id) );
       
 

DELIMITER $$
CREATE FUNCTION `formatar_telefone`(telefone VARCHAR(10))
RETURNS VARCHAR(14)
DETERMINISTIC
BEGIN
 RETURN CONCAT('(', SUBSTRING(telefone, 1, 2), ') ', SUBSTRING(telefone, 3, 4), '-',
SUBSTRING(telefone, 7, 4));
END$$
DELIMITER ;






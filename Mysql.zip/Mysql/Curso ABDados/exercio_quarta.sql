select
fr.nome as nome_fornecedor,
fr. cpf_cnpj,
fr.data_cadastro,
qt_produto_fornecedor(id) 				
FROM fornecedor as fr;


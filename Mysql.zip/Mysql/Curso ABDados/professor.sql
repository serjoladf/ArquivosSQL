SELECT * FROM exercicio_abd.professor;

INSERT INTO professor(nome_professor,cpf,rg,dataNasc,email,cor_de_pele,matricula,telefone,lotacao,nacionalidade,naturalidade,turma_id,sexo_id) 
VALUES
("joao roberto","011.609.055-01","1.689-001","2001-07-07","joaor@gmail.com","2000-1","judaico","78642-0001","unidae-06","brasileiro","fortaleza",1,1),
("jose silva","012.809.155-02","3.667-002","2002-08-08","silvajosegmail.com","2000-2","europeia","79998-0004","unidae-05","brasileiro","goias",2,1),
("mario","013.810.156-03","4.68-003","2003-09-09","mariok@gmail.com","3000-3","europeia","78888-0003","unidae-03","brasileiro","rio de Janeiro",3,1),
("paulo","014.811.157-04","5.623-004","2004-10-10","pualo@gmail.com","4000-4","africana","87777-0004","unidae-02","brasileiro","sao paulo",4,1),
("iranice","015.812.158-05","6.610-005","2005-09-09","iranicea@gmail.com","5000-5","aleman","69666-0005","unidae-02","brasileiro","brasilia",5,2);

SELECT*FROM professor AS pf
inner JOIN turma AS tm ON pf.id = tm.id
inner JOIN sexo AS sx ON pf.sexo_id = sx.id
inner JOIN disciplina AS ds ON pf.id = ds.id;

SELECT COUNT(*) as Total_professor FROM professor;

SELECT 
sexo_id,
COUNT(sexo_id) qt_sexo 
FROM professor
GROUP BY sexo_id;

ALTER TABLE professor RENAME COLUMN nome TO nome_professor;

select 
a.nome,
a.cpf,
a.datanasc,
a.email,
s.descricao,
t.turno,
t.data_inicio,
t.data_fim,
c.nome_curso,
c.modalidade,
c.carga_horaria ch_curso,
p.nome nome_professor,
p.matricula,
p.cpf cfp_professor
from aluno a
inner join sexo s on s.id = a.sexo_id
inner join turma_has_aluno ta on ta.aluno_id = a.id
inner join turma t on t.id = ta.turma_id
inner join turma_has_curso tc on tc.turma_id = t.id
inner join curso c on c.id = tc.curso_id
inner join turma_has_professor tp on tp.turma_id = t.id
inner join professor p on p.id = tp.professor_id;


select 
s.descricao,
count(s.descricao) as total_sexo_professor
from professor as p
inner join sexo s on s.id = a.sexo_id
inner join turma_has_aluno ta on ta.aluno_id = a.id
inner join turma t on t.id = ta.turma_id
inner join turma_has_curso tc on tc.turma_id = t.id
inner join curso c on c.id = tc.curso_id
inner join turma_has_professor tp on tp.turma_id = t.id
inner join professor on p.id = tp.professor_id
group by s.descricao;


update professor
set id=10
where id=20;
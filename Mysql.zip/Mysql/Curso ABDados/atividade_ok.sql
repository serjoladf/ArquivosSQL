CREATE DATABASE  IF NOT EXISTS `imobiliaria` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `imobiliaria`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: imobiliaria
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cargos`
--

DROP TABLE IF EXISTS `cargos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargos` (
  `id_cargo` int NOT NULL AUTO_INCREMENT,
  `funcionario_id` int DEFAULT NULL,
  `decricao_cargo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cargo`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `cargos_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargos`
--

LOCK TABLES `cargos` WRITE;
/*!40000 ALTER TABLE `cargos` DISABLE KEYS */;
INSERT INTO `cargos` VALUES (1,1,'analista de dados'),(2,2,'analista de gerencial'),(3,3,'analista de sistemas'),(4,4,'auxiliar de bancos'),(5,5,'Operador de internet');
/*!40000 ALTER TABLE `cargos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endereco_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `endereco_id` (`endereco_id`),
  KEY `contato_id` (`contato_id`),
  CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`endereco_id`) REFERENCES `endereco` (`id`),
  CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`contato_id`) REFERENCES `contato` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,1,1,'Leo Bomfim','01360905597'),(2,2,2,'anisio Bomfim','01360905597'),(3,3,3,'Banene Bomfim','01360905597'),(4,4,4,'Luiz Melo','01350905597'),(5,5,5,'Cassio Gomes','012605905597');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato`
--

DROP TABLE IF EXISTS `contato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contato_id` int DEFAULT NULL,
  `cliente_id` int DEFAULT NULL,
  `funcionario_id` int DEFAULT NULL,
  `imobiliaria_id` int DEFAULT NULL,
  `filial_id` int DEFAULT NULL,
  `nome_contato` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contato_id` (`contato_id`),
  CONSTRAINT `contato_ibfk_1` FOREIGN KEY (`contato_id`) REFERENCES `tipo_email` (`id`),
  CONSTRAINT `contato_ibfk_2` FOREIGN KEY (`contato_id`) REFERENCES `tipo_telefone` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato`
--

LOCK TABLES `contato` WRITE;
/*!40000 ALTER TABLE `contato` DISABLE KEYS */;
INSERT INTO `contato` VALUES (1,1,0,1,0,0,'Sérgio'),(2,2,0,2,0,0,'André'),(3,1,0,3,0,0,'Márcio'),(4,1,0,4,0,0,'imobiliaria'),(5,2,1,0,0,0,'Alberto'),(6,2,2,0,0,0,'Anderson'),(7,3,3,0,0,0,'Papada');
/*!40000 ALTER TABLE `contato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato_email`
--

DROP TABLE IF EXISTS `contato_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_email_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipo_email_id` (`tipo_email_id`),
  CONSTRAINT `contato_email_ibfk_1` FOREIGN KEY (`tipo_email_id`) REFERENCES `tipo_email` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato_email`
--

LOCK TABLES `contato_email` WRITE;
/*!40000 ALTER TABLE `contato_email` DISABLE KEYS */;
INSERT INTO `contato_email` VALUES (1,1,1,'serjola_func@gmail.com'),(2,1,2,'andre_func@gmail.com'),(3,1,3,'marcio_func@gmail.com'),(4,2,4,'admimoabiliaria@gmail.com'),(5,3,5,'cliente_alberto@gmail.com'),(6,3,6,'cliente_anderson@gmail.com'),(7,3,7,'cliente_papada@gmail.com');
/*!40000 ALTER TABLE `contato_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato_telefone`
--

DROP TABLE IF EXISTS `contato_telefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato_telefone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_telefone_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `telefone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipo_telefone_id` (`tipo_telefone_id`),
  CONSTRAINT `contato_telefone_ibfk_1` FOREIGN KEY (`tipo_telefone_id`) REFERENCES `tipo_telefone` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato_telefone`
--

LOCK TABLES `contato_telefone` WRITE;
/*!40000 ALTER TABLE `contato_telefone` DISABLE KEYS */;
INSERT INTO `contato_telefone` VALUES (1,1,1,'61 9864 22423'),(2,2,2,'61 9873 2456'),(3,3,3,'61 99162 9090'),(4,4,4,'61 3387 8067'),(5,1,5,'71 5678 9070'),(6,2,5,'21 3567 4012'),(7,3,5,'61 3591 8119');
/*!40000 ALTER TABLE `contato_telefone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `endereco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `imovel_id` int DEFAULT NULL,
  `logradouro` varchar(100) DEFAULT NULL,
  `numero` int DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `bairro` varchar(150) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `imovel_id` (`imovel_id`),
  CONSTRAINT `endereco_ibfk_1` FOREIGN KEY (`imovel_id`) REFERENCES `imovel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco`
--

LOCK TABLES `endereco` WRITE;
/*!40000 ALTER TABLE `endereco` DISABLE KEYS */;
INSERT INTO `endereco` VALUES (1,1,'Rua sÃ£o marcos',12,'Apartamento','São Gonsalo','Salvador','Bahia','48800001'),(2,2,'Rua joÃ£o marcos',13,'casa','Retiro','Salvador','Bahia','48800013'),(3,3,'Rua joÃ£o tradicional',123,'Apartamento','Lobato','Salvador','Bahia','48800033'),(4,2,'Rua joÃ£o arapoanga',3,'Apartamento','Rio Sena','Salvador','Bahia','48770033'),(5,1,'Rua do melado',103,'casa','Cajazeira','Salvador','Bahia','48800153');
/*!40000 ALTER TABLE `endereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filial`
--

DROP TABLE IF EXISTS `filial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filial` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endereco_id` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `localizacao` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `endereco_id` (`endereco_id`),
  CONSTRAINT `filial_ibfk_1` FOREIGN KEY (`endereco_id`) REFERENCES `endereco` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filial`
--

LOCK TABLES `filial` WRITE;
/*!40000 ALTER TABLE `filial` DISABLE KEYS */;
INSERT INTO `filial` VALUES (1,1,'Correa & Correa','SHN'),(2,2,'Correa & Camargo','SHN'),(3,3,'Correa & Camargo','STN'),(4,4,'sonhos & Casa','Sobradinho'),(5,5,'Correa & Correa','Sobradinho');
/*!40000 ALTER TABLE `filial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endereco_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL,
  `data_emissao` date DEFAULT NULL,
  `salario` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `endereco_id` (`endereco_id`),
  KEY `contato_id` (`contato_id`),
  CONSTRAINT `funcionarios_ibfk_1` FOREIGN KEY (`endereco_id`) REFERENCES `endereco` (`id`),
  CONSTRAINT `funcionarios_ibfk_2` FOREIGN KEY (`contato_id`) REFERENCES `contato` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
INSERT INTO `funcionarios` VALUES (1,1,1,'Serjoladf','01350906692','2005-01-01',1559.05),(2,2,2,'joaobahia','01350906692','2007-07-01',2050.06),(3,3,3,'marcio andre','01350906692','2001-05-01',3020.07),(4,4,4,'leao da Barra','01350906692','2003-03-01',1200.08),(5,5,5,'cascao de juda','01350906692','2008-02-01',2500.00);
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gerencia`
--

DROP TABLE IF EXISTS `gerencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gerencia` (
  `id_gerencia` int NOT NULL AUTO_INCREMENT,
  `funcionario_id` int DEFAULT NULL,
  `id_filial` int DEFAULT NULL,
  PRIMARY KEY (`id_gerencia`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `gerencia_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gerencia`
--

LOCK TABLES `gerencia` WRITE;
/*!40000 ALTER TABLE `gerencia` DISABLE KEYS */;
INSERT INTO `gerencia` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5);
/*!40000 ALTER TABLE `gerencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imovel`
--

DROP TABLE IF EXISTS `imovel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imovel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_residencia` varchar(200) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `dia_contrato` date DEFAULT NULL,
  `Valor_estimado` float(10,2) DEFAULT NULL,
  `cond_status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imovel`
--

LOCK TABLES `imovel` WRITE;
/*!40000 ALTER TABLE `imovel` DISABLE KEYS */;
INSERT INTO `imovel` VALUES (1,'aluguel','casa de familia','2001-12-01',2300.00,'alugado'),(2,'Vendido','Escritório','1999-12-01',350000.00,'comprado'),(3,'aluguel','empresa','1998-12-01',5000.00,'Comprado'),(4,'vendido','casa de familia','2001-03-05',24300.00,'alugado'),(5,'financiado','casa de familia','1987-02-05',650000.00,'vendido');
/*!40000 ALTER TABLE `imovel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `informacao_cliente`
--

DROP TABLE IF EXISTS `informacao_cliente`;
/*!50001 DROP VIEW IF EXISTS `informacao_cliente`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `informacao_cliente` AS SELECT 
 1 AS `nome`,
 1 AS `cpf`,
 1 AS `logradouro`,
 1 AS `numero`,
 1 AS `complemento`,
 1 AS `bairro`,
 1 AS `cidade`,
 1 AS `estado`,
 1 AS `cep`,
 1 AS `nome_contato`,
 1 AS `telefone`,
 1 AS `email`,
 1 AS `descricao_operacao`,
 1 AS `tipo_residencia`,
 1 AS `descricao`,
 1 AS `dia_contrato`,
 1 AS `valor_estimado`,
 1 AS `cond_status`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `log_atividade`
--

DROP TABLE IF EXISTS `log_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_atividade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `funcionario_id` int DEFAULT NULL,
  `Timestamp` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `funcionario_id` (`funcionario_id`),
  CONSTRAINT `log_atividade_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_atividade`
--

LOCK TABLES `log_atividade` WRITE;
/*!40000 ALTER TABLE `log_atividade` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operacao`
--

DROP TABLE IF EXISTS `operacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) DEFAULT NULL,
  `data_servico` date DEFAULT NULL,
  `cliente_id` int DEFAULT NULL,
  `funcionario_id` int DEFAULT NULL,
  `imovel_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `funcionario_id` (`funcionario_id`),
  KEY `imovel_id` (`imovel_id`),
  KEY `cliente_id` (`cliente_id`),
  CONSTRAINT `operacao_ibfk_1` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`),
  CONSTRAINT `operacao_ibfk_2` FOREIGN KEY (`imovel_id`) REFERENCES `imovel` (`id`),
  CONSTRAINT `operacao_ibfk_3` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operacao`
--

LOCK TABLES `operacao` WRITE;
/*!40000 ALTER TABLE `operacao` DISABLE KEYS */;
INSERT INTO `operacao` VALUES (1,'alugado','2000-01-01',1,1,1),(2,'alugado','2009-06-01',2,2,2),(3,'alugado','2001-02-01',3,3,3),(4,'vendido','2002-03-01',4,4,4),(5,'vendido','2008-05-01',5,5,5);
/*!40000 ALTER TABLE `operacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servico_imovel`
--

DROP TABLE IF EXISTS `servico_imovel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servico_imovel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `servico_id` int DEFAULT NULL,
  `data_execucao` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `servico_id` (`servico_id`),
  CONSTRAINT `servico_imovel_ibfk_1` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servico_imovel`
--

LOCK TABLES `servico_imovel` WRITE;
/*!40000 ALTER TABLE `servico_imovel` DISABLE KEYS */;
INSERT INTO `servico_imovel` VALUES (1,1,'2000-01-01'),(2,2,'2001-02-04'),(3,3,'2020-02-03'),(4,4,'2010-03-05'),(5,5,'2005-01-13');
/*!40000 ALTER TABLE `servico_imovel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicos`
--

DROP TABLE IF EXISTS `servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(140) DEFAULT NULL,
  `imovel_id` int DEFAULT NULL,
  `custo_asssociado` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `imovel_id` (`imovel_id`),
  CONSTRAINT `servicos_ibfk_1` FOREIGN KEY (`imovel_id`) REFERENCES `imovel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicos`
--

LOCK TABLES `servicos` WRITE;
/*!40000 ALTER TABLE `servicos` DISABLE KEYS */;
INSERT INTO `servicos` VALUES (1,'serviço de manutenção',1,1400.03),(2,'serviço de amparagem',2,180.03),(3,'serviço auxiliar',3,1700.03),(4,'serviço engrenagem',2,1900.03),(5,'serviço de manutenção',1,3200.03);
/*!40000 ALTER TABLE `servicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_email`
--

DROP TABLE IF EXISTS `tipo_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_email`
--

LOCK TABLES `tipo_email` WRITE;
/*!40000 ALTER TABLE `tipo_email` DISABLE KEYS */;
INSERT INTO `tipo_email` VALUES (1,'PESSOAL',NULL),(2,'EMPRESA',NULL),(3,'CLIENTE',NULL);
/*!40000 ALTER TABLE `tipo_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_telefone`
--

DROP TABLE IF EXISTS `tipo_telefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_telefone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_telefone`
--

LOCK TABLES `tipo_telefone` WRITE;
/*!40000 ALTER TABLE `tipo_telefone` DISABLE KEYS */;
INSERT INTO `tipo_telefone` VALUES (1,'RESIDENCIAL',NULL),(2,'PESSOAL',NULL),(3,'EMPRESARIA',NULL),(4,'HOTEL',NULL);
/*!40000 ALTER TABLE `tipo_telefone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'imobiliaria'
--

--
-- Dumping routines for database 'imobiliaria'
--
/*!50003 DROP FUNCTION IF EXISTS `retorne_relatorio` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `retorne_relatorio`(id int) RETURNS varchar(1000) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
DECLARE retorne_relatorio varchar(1000);
select 
concat(c.nome, ' - ',
c.cpf, ' - ',
op.descricao, ' - ',
op.data_servico, ' - ',
i.tipo_residencia, ' - ',
i.descricao, ' - ',
i.dia_contrato, ' - ',
i.valor_estimado, ' - ',
i.cond_status)
into retorne_relatorio
from clientes as c
inner join operacao as op on c.id = op.id
inner join endereco as e on e.id = c.endereco_id
inner join imovel as i on i.id = e.id
where c.id = id;
RETURN retorne_relatorio;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `informacao_cliente`
--

/*!50001 DROP VIEW IF EXISTS `informacao_cliente`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `informacao_cliente` AS select `c`.`nome` AS `nome`,`c`.`cpf` AS `cpf`,`e`.`logradouro` AS `logradouro`,`e`.`numero` AS `numero`,`e`.`complemento` AS `complemento`,`e`.`bairro` AS `bairro`,`e`.`cidade` AS `cidade`,`e`.`estado` AS `estado`,`e`.`cep` AS `cep`,`co`.`nome_contato` AS `nome_contato`,`ct`.`telefone` AS `telefone`,`ce`.`email` AS `email`,`op`.`descricao` AS `descricao_operacao`,`i`.`tipo_residencia` AS `tipo_residencia`,`i`.`descricao` AS `descricao`,`i`.`dia_contrato` AS `dia_contrato`,`i`.`Valor_estimado` AS `valor_estimado`,`i`.`cond_status` AS `cond_status` from ((((((`clientes` `c` join `endereco` `e` on((`e`.`id` = `c`.`endereco_id`))) join `contato` `co` on((`co`.`id` = `c`.`contato_id`))) join `contato_telefone` `ct` on((`ct`.`id` = `co`.`id`))) join `contato_email` `ce` on((`ce`.`id` = `co`.`id`))) join `operacao` `op` on((`c`.`id` = `op`.`id`))) join `imovel` `i` on((`i`.`id` = `e`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-22 19:18:58

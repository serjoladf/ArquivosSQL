select						
CASE    
		WHEN idade >= 18 and idade <= 30 THEN "18-30"
		WHEN idade >= 31 and idade <= 40 THEN "31-40"
		WHEN idade >= 41 and idade <= 50 THEN "18-30"
		ELSE "acima de 50"
        END AS Faixa_Etaria,
    count(*) as "Quantidade por Faixa"
    from(
    select retor_idade(datanascimento) as idade
     from colaborador
   ) as idades 
   group by
     faixa_Etaria;


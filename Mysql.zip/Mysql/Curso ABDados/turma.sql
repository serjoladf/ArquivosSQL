SELECT * FROM exercicio_abd.turma;

INSERT INTO turma(cod_da_turma,turno,data_inicio,data_fim)
VALUES("100A","matutino","2001-03-01","2006-11-30"),
("200A","vespertino","2002-04-02","2007-12-30"),
("300A","noturno","2002-03-05","2008-01-30"),
("400A","vespertino","2003-06-01","2009-02-28"),
("500A","matutino","2004-07-01","2010-03-30");
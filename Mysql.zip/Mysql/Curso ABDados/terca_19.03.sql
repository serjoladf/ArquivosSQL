select * from colaborador where nome_colaborador = "MARCOS" or nome_colaborador = "albert" and foto_34 is null;

select tipo_sanguineo, Count(*) -- Retorna a quantidade
 from colaborador
group by 
tipo_sanguineo;


select 
avg(salario) AS media_salarial
from colaborador as col
inner join cargo on cargo.id = col.cargo_id;

select 
sum(salario) -- retorna a soma
from colaborador as col
inner join cargo on cargo.id = col.cargo_id;

select 
max(salario) -- retorna a soma
from colaborador as col
inner join cargo on cargo.id = col.cargo_id;

select 
min(salario) -- retorna a soma
from colaborador as col
inner join cargo on cargo.id = col.cargo_id;

select 
col.nome_colaborador,
length(col.nome_colaborador) as contador
from colaborador as col
where col.nome_colaborador like "%ber%";


select concat("R$ ",Salario," Reais") from Cargo;

select lower(razao_social) from empresa;


select
c.nome_colaborador,
ca.salario
from colaborador as c
inner join cargo on ca.id = c.cargo_id
where ca.salario = (select min(ca.salario)
from colaborador c inner join cargo ca on c.cargo_id = ca.id);
create view informacao_cliente as
select 
c.nome,
c.cpf,
e.logradouro,
e.numero,
e.complemento,
e.bairro,
e.cidade,
e.estado,
e.cep,
co.nome_contato,
ct.telefone,
ce.email,
op.descricao as descricao_operacao,
i.tipo_residencia, i.descricao, i.dia_contrato, i.valor_estimado, i.cond_status
from clientes as c
inner join endereco as e on e.id = c.endereco_id
inner join contato as co on co.id = c.contato_id
inner join contato_telefone as ct on ct.id = co.id
inner join contato_email as ce on ce.id = co.id
inner join operacao as op on c.id = op.id
inner join imovel as i on i.id = e.id;

select * from informacao_cliente;


use imobiliaria
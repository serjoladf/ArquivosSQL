create table log_funcao
(
id int auto_increment
primary key,
Operacao varchar(20) null,
descricao_menu varchar(100) null,
imagem_menu varchar(50),
metodo varchar(50),
data_modificacao timestamp default current_timestamp() not null,
id_tabela int
);

DELIMITER $$
CREATE TRIGGER log_update_funcao
AFTER UPDATE ON funcao
FOR EACH ROW
BEGIN
    INSERT INTO log_funcao
    (operacao,descricao_menu,imagem_menu,metodo,id_tabela)
    VALUES ("Update Antigo", old.descricao_menu,old.imagem_menu,old.metodo, old.id);
    
    INSERT INTO log_funcao
    (operacao,descricao_menu,imagem_menu,metodo,id_tabela)
    VALUES ("Update", new.descricao_menu,new.imagem_menu,new.metodo, id);
END$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER log_insert_funcao
BEFORE INSERT ON funcao
FOR EACH ROW
BEGIN
      INSERT INTO log_funcao
	(operacao,descricao_menu,imagem_menu,metodo,id_tabela)
   VALUES ("Insert", new.descricao_menu,new.imagem_menu,new.metodo, new.id);
END$$
DELIMITER ;

DELIMITER $$

CREATE TRIGGER log_delete_funcao
BEFORE DELETE ON funcao
FOR EACH ROW
BEGIN 
    INSERT INTO log_funcao (operacao, descricao_menu,imagem_menu, metodo, id_tabela)
    VALUES ('Delete', old.descricao_menu, old.imagem_menu, old.metodo, old.id);
END$$

DELIMITER ;

-- DROP TRIGGER IF EXISTS log_delete_funcao;
-- DROP TRIGGER IF EXISTS log_insert_funcao;
-- DROP TRIGGER IF EXISTS log_update_funcao;
-- drop table log_funcao;
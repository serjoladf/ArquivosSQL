# Define a function that acts like a parrot
def parrot():
    answer = input("Digite seu nome")
    print(answer)

# Call the parrot function
parrot()
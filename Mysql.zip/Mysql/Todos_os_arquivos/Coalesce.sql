
select
COALESCE(inscricao_Estadual,RAND(6)),
COALESCE(inscricao_municipal,RAND(6)),
COALESCE(Matriz_filial,"Nada Registrado")
from empresa
where inscricao_Estadual or
inscricao_municipal or
Matriz_filial is null ;

select
razao_social,
nome_fantasia,
COALESCE(inscricao_Estadual,RAND(6)),
COALESCE(inscricao_municipal,RAND(6)),
COALESCE(Matriz_filial,"Nada Registrado")
from empresa
where inscricao_Estadual or
inscricao_municipal or
razao_social or
nome_fantasia or
Matriz_filial is null ;

select
razao_social,
nome_fantasia,
COALESCE(inscricao_Estadual,RAND(6)),
COALESCE(inscricao_municipal,RAND(6)),
COALESCE(Matriz_filial,"Nada Registrado")
from empresa
where 
inscricao_Estadual is null or
inscricao_municipal is null or
razao_social is null or
nome_fantasia is null or
Matriz_filial is null ;



SELECT *
FROM fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Numero_pedido FROM pedidos WHERE id = 1);


UPDATE produtos
SET valor = 
    CASE 
        WHEN id = 1 THEN 2.00
        WHEN id = 2 THEN 2.20
        WHEN id = 3 THEN 2.79
        WHEN id = 4 THEN 3.08
        WHEN id = 5 THEN 2.10
        WHEN id = 6 THEN 3.15
        WHEN id = 7 THEN 5.00
        WHEN id = 8 THEN 6.70
        WHEN id = 9 THEN 7.00
        WHEN id = 10 THEN 8.20
        ELSE valor
    END;


-- Tabela de Fornecedor
CREATE TABLE fornecedor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_fornecedor VARCHAR(100)
);

-- Tabela de Produtos
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(100),
    fornecedor_id INT,
    FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(id)
);

-- Inserções na tabela fornecedor
INSERT INTO fornecedor (nome_fornecedor) VALUES
('Fornecedor A'),
('Fornecedor B'),
('Fornecedor C'),
('Fornecedor D'),
('Fornecedor E'),
('Fornecedor F'),
('Fornecedor G'),
('Fornecedor H'),
('Fornecedor I'),
('Fornecedor J');

UPDATE fornecedor
SET nome_fornecedor = 
    CASE 
        WHEN id = 1 THEN "Feijão"
        WHEN id = 2 THEN "Arroz"
        WHEN id = 3 THEN "Macarrão"
        WHEN id = 4 THEN "Café"
        WHEN id = 5 THEN "Miojo"
        WHEN id = 6 THEN "Farinha"
        WHEN id = 7 THEN "Sazon"
        WHEN id = 8 THEN "Feijao Preto"
        WHEN id = 9 THEN "Sabão em pó"
        WHEN id = 10 THEN "Oleo"
        ELSE nome_fornecedor
    END;

-- Inserções na tabela produtos
INSERT INTO produtos (nome_produto, fornecedor_id) VALUES
('Produto 1', 1),
('Produto 2', 2),
('Produto 3', 3),
('Produto 4', 4),
('Produto 5', 5),
('Produto 6', 6),
('Produto 7', 7),
('Produto 8', 8),
('Produto 9', 9),
('Produto 10', 10);

SELECT Nome_Fornecedor
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor < 2.60);


SELECT*
FROM Fornecedor f
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor = 2.10);

SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor < 2.60);


SELECT*
FROM Fornecedor f
INNER JOIN produtos p ON p.fornecedor_id = f.id
WHERE EXISTS (SELECT Nome_Produto FROM Produtos p WHERE P.Fornecedor_id
= f.Id AND valor = 2.10);
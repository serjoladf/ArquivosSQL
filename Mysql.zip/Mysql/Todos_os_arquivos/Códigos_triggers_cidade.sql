create table log_cidade
(
id int auto_increment
primary key,
Operacao varchar(20) null,
nome varchar(100) null,
codigo_IBGE int,
data_modificacao timestamp default current_timestamp() not null,
id_tabela int null
);

DELIMITER $$
CREATE TRIGGER log_update_cidade
AFTER UPDATE ON cidade
FOR EACH ROW
BEGIN
    INSERT INTO log_cidade
    (operacao,nome,codigo_IBGE,id_tabela)
    VALUES ("Update Antigo", old.nome,old.codigo_IBGE, old.id);
    
     INSERT INTO log_cidade
    (operacao,nome,codigo_IBGE,id_tabela)
    VALUES ("Update", new.nome, new.codigo_IBGE, new.id);
END$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER log_insert_cidade
BEFORE INSERT ON cidade
FOR EACH ROW
BEGIN
    INSERT INTO log_cidade (operacao,nome,codigo_IBGE)
    VALUES ("Insert",new.nome,new.codigo_IBGE);
END$$
DELIMITER ;

DELIMITER $$

CREATE TRIGGER log_delete_cidade
BEFORE DELETE ON cidade
FOR EACH ROW
BEGIN
    INSERT INTO log_cidade (operacao, id, nome,codigo_IBGE)
    VALUES ('Delete', OLD.id, OLD.nome, OLD.codigo_IBGE);
END$$

DELIMITER ;



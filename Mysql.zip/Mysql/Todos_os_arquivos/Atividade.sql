DELIMITER $$

CREATE TRIGGER empresa_produto_trigger
AFTER INSERT ON Produto
FOR EACH ROW
BEGIN
    INSERT INTO empresa_produto (produto_id)
    VALUES (NEW.id); 
END$$

DELIMITER ;



create table log_tipo_email
(
id int auto_increment
primary key,
Operacao varchar(20) null,
nome varchar(100) null,
descricao varchar(200) null,
data_modificacao timestamp default current_timestamp() not null,
id_tabela int null
);


DELIMITER $$
CREATE TRIGGER log_update_tipo_email
AFTER UPDATE ON tipo_email
FOR EACH ROW
BEGIN
    INSERT INTO log_tipo_email 
    (operacao,nome,descricao,id_tabela)
    VALUES ("Update Antigo", old.nome,old.descricao,old.id);
    
     INSERT INTO log_tipo_email 
    (operacao,nome,descricao,id_tabela)
    VALUES ("Update", new.nome,new.descricao,new.id);
END$$
DELIMITER ;

SELECT * FROM erp_senai.tipo_email;DELIMITER $$
CREATE TRIGGER log_insert_email
BEFORE INSERT ON tipo_email
FOR EACH ROW
BEGIN
    INSERT INTO log_tipo_email (operacao,nome,descricao)
    VALUES ("Insert",new.nome,new.descricao);
END$$
DELIMITER ;

drop trigger log_insert_email;

DELIMITER $$

CREATE TRIGGER log_delete_tipo_email
BEFORE DELETE ON tipo_email
FOR EACH ROW
BEGIN
    INSERT INTO log_tipo_email (operacao, id, nome, descricao)
    VALUES ('Delete', OLD.id, OLD.nome, OLD.descricao);
END$$

DELIMITER ;



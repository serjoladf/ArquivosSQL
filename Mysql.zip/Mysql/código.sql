-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: erp_senai
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agencia_banco`
--

DROP TABLE IF EXISTS `agencia_banco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agencia_banco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cep_id` int DEFAULT NULL,
  `banco_id` int DEFAULT NULL,
  `codigo` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `endereco` varchar(120) DEFAULT NULL,
  `telefone` varchar(15) DEFAULT NULL,
  `gerente` varchar(30) DEFAULT NULL,
  `contato` varchar(30) DEFAULT NULL,
  `obs` text,
  PRIMARY KEY (`id`),
  KEY `cep_id` (`cep_id`),
  KEY `banco_id` (`banco_id`),
  CONSTRAINT `agencia_banco_ibfk_1` FOREIGN KEY (`cep_id`) REFERENCES `cep` (`id`),
  CONSTRAINT `agencia_banco_ibfk_2` FOREIGN KEY (`banco_id`) REFERENCES `banco` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agencia_banco`
--

LOCK TABLES `agencia_banco` WRITE;
/*!40000 ALTER TABLE `agencia_banco` DISABLE KEYS */;
INSERT INTO `agencia_banco` VALUES (1,1,1,1234,'Agência Paulista','Avenida Paulista, 1000','1133224455','João Silva','joao.silva@banco.com','Nenhuma'),(2,2,2,5678,'Agência Rio Branco','Avenida Rio Branco, 200','2133224455','Maria Souza','maria.souza@banco.com','Nenhuma'),(3,3,3,9101,'Agência Afonso Pena','Avenida Afonso Pena, 300','3133224455','José Oliveira','jose.oliveira@banco.com','Nenhuma'),(4,4,4,1121,'Agência Penha','Avenida Nossa Senhora da Penha, 400','2733224455','Ana Costa','ana.costa@banco.com','Nenhuma'),(5,5,5,3141,'Agência Borges de Medeiros','Avenida Borges de Medeiros, 500','5133224455','Carlos Pereira','carlos.pereira@banco.com','Nenhuma'),(6,6,6,5161,'Agência Beira Mar Norte','Avenida Beira Mar Norte, 600','4833224455','Roberto Lima','roberto.lima@banco.com','Nenhuma'),(7,7,7,7181,'Agência XV de Novembro','Rua XV de Novembro, 700','4133224455','Fernanda Martins','fernanda.martins@banco.com','Nenhuma'),(8,8,8,9202,'Agência Sete de Setembro','Avenida Sete de Setembro, 800','7133224455','Marcos Fernandes','marcos.fernandes@banco.com','Nenhuma'),(9,9,9,1223,'Agência Conde da Boa Vista','Avenida Conde da Boa Vista, 900','8133224455','Paula Araújo','paula.araujo@banco.com','Nenhuma'),(10,10,10,3242,'Agência Beira Mar','Avenida Beira Mar, 1000','8533224455','Bruno Mendes','bruno.mendes@banco.com','Nenhuma'),(11,11,11,5262,'Agência Presidente Vargas','Avenida Presidente Vargas, 1100','9133224455','Carla Souza','carla.souza@banco.com','Nenhuma'),(12,12,12,7282,'Agência Eduardo Ribeiro','Avenida Eduardo Ribeiro, 1200','9233224455','Rafael Santos','rafael.santos@banco.com','Nenhuma'),(13,13,13,9303,'Agência Holandeses','Avenida dos Holandeses, 1300','9833224455','Patrícia Almeida','patricia.almeida@banco.com','Nenhuma'),(14,14,14,1324,'Agência Goiás','Avenida Goiás, 1400','6233224455','Fábio Lima','fabio.lima@banco.com','Nenhuma'),(15,15,15,3344,'Agência Mato Grosso','Avenida Mato Grosso, 1500','6533224455','Juliana Reis','juliana.reis@banco.com','Nenhuma');
/*!40000 ALTER TABLE `agencia_banco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banco`
--

DROP TABLE IF EXISTS `banco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` int DEFAULT NULL,
  `nome_banco` varchar(100) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banco`
--

LOCK TABLES `banco` WRITE;
/*!40000 ALTER TABLE `banco` DISABLE KEYS */;
INSERT INTO `banco` VALUES (1,1,'Banco do Brasil','https://www.bb.com.br'),(2,2,'Caixa Econômica Federal','https://www.caixa.gov.br'),(3,3,'Bradesco','https://www.bradesco.com.br'),(4,4,'Itaú','https://www.itau.com.br'),(5,5,'Santander','https://www.santander.com.br'),(6,6,'HSBC','https://www.hsbc.com.br'),(7,7,'Citibank','https://www.citibank.com.br'),(8,8,'Safra','https://www.safra.com.br'),(9,9,'Banco Original','https://www.original.com.br'),(10,10,'Banco Inter','https://www.bancointer.com.br'),(11,11,'Banrisul','https://www.banrisul.com.br'),(12,12,'Banco do Nordeste','https://www.bnb.gov.br'),(13,13,'Banco da Amazônia','https://www.bancoamazonia.com.br'),(14,14,'BTG Pactual','https://www.btgpactual.com'),(15,15,'Banco Modal','https://www.modal.com.br');
/*!40000 ALTER TABLE `banco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_cargo` varchar(20) DEFAULT NULL,
  `descricao` text,
  `salario` double(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'Gerente','Gerente de Setor',5000.00),(2,'Assistente','Assistente Administrativo',2500.00),(3,'Analista','Analista de Sistemas',4000.00),(4,'Coordenador','Coordenador de Projetos',4500.00),(5,'Supervisor','Supervisor de Equipe',3000.00),(6,'Auxiliar','Auxiliar de Escritório',2000.00),(7,'Diretor','Diretor Executivo',8000.00),(8,'Estagiário','Estagiário de TI',1500.00),(9,'Consultor','Consultor de Vendas',3500.00),(10,'Operador','Operador de Máquinas',2800.00),(11,'Engenheiro','Engenheiro de Produção',6000.00),(12,'Técnico','Técnico em Informática',3200.00),(13,'Designer','Designer Gráfico',3700.00),(14,'Desenvolvedor','Desenvolvedor de Software',4500.00),(15,'Analista Financeiro','Analista de Finanças',4000.00);
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cep`
--

DROP TABLE IF EXISTS `cep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cep` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cidade_id` int DEFAULT NULL,
  `cep` varchar(20) DEFAULT NULL,
  `logradouro` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cidade_id` (`cidade_id`),
  CONSTRAINT `cep_ibfk_1` FOREIGN KEY (`cidade_id`) REFERENCES `cidade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cep`
--

LOCK TABLES `cep` WRITE;
/*!40000 ALTER TABLE `cep` DISABLE KEYS */;
INSERT INTO `cep` VALUES (1,1,'01000-000','Avenida Paulista','Bela Vista'),(2,2,'20000-000','Avenida Rio Branco','Centro'),(3,3,'30100-000','Avenida Afonso Pena','Centro'),(4,4,'29000-000','Avenida Nossa Senhora da Penha','Praia do Canto'),(5,5,'90000-000','Avenida Borges de Medeiros','Centro Histórico'),(6,6,'88000-000','Avenida Beira Mar Norte','Centro'),(7,7,'80000-000','Rua XV de Novembro','Centro'),(8,8,'40000-000','Avenida Sete de Setembro','Centro'),(9,9,'50000-000','Avenida Conde da Boa Vista','Boa Vista'),(10,10,'60000-000','Avenida Beira Mar','Meireles'),(11,11,'66000-000','Avenida Presidente Vargas','Campina'),(12,12,'69000-000','Avenida Eduardo Ribeiro','Centro'),(13,13,'65000-000','Avenida dos Holandeses','Calhau'),(14,14,'74000-000','Avenida Goiás','Setor Central'),(15,15,'78000-000','Avenida Mato Grosso','Centro Sul');
/*!40000 ALTER TABLE `cep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfop`
--

DROP TABLE IF EXISTS `cfop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `CFOP` int DEFAULT NULL,
  `descricao` text,
  `aplicacao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfop`
--

LOCK TABLES `cfop` WRITE;
/*!40000 ALTER TABLE `cfop` DISABLE KEYS */;
INSERT INTO `cfop` VALUES (1,1101,'Compra para industrialização','Compra de mercadorias para serem industrializadas'),(2,1102,'Compra para comercialização','Compra de mercadorias para revenda'),(3,1111,'Compra para ativo imobilizado','Compra de mercadorias para o ativo imobilizado'),(4,1113,'Compra de material de uso e consumo','Compra de materiais para uso e consumo do estabelecimento'),(5,1116,'Compra para prestação de serviços','Compra de materiais para prestação de serviços'),(6,1201,'Devolução de venda de produção do estabelecimento','Devolução de venda de produtos industrializados'),(7,1202,'Devolução de venda de mercadoria adquirida ou recebida de terceiros','Devolução de venda de mercadorias'),(8,1203,'Devolução de venda de ativo imobilizado','Devolução de venda de ativos imobilizados'),(9,1204,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(10,1205,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(11,1206,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(12,1207,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(13,1208,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(14,1209,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo'),(15,1210,'Devolução de venda de material de uso e consumo','Devolução de venda de materiais de uso e consumo');
/*!40000 ALTER TABLE `cfop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cidade`
--

DROP TABLE IF EXISTS `cidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cidade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estado_id` int DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `codigo_IBGE` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estado_id` (`estado_id`),
  CONSTRAINT `cidade_ibfk_1` FOREIGN KEY (`estado_id`) REFERENCES `estado` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cidade`
--

LOCK TABLES `cidade` WRITE;
/*!40000 ALTER TABLE `cidade` DISABLE KEYS */;
INSERT INTO `cidade` VALUES (1,8,'Mata de São João',2921008),(2,2,'Rio de Janeiro',3304557),(3,3,'Belo Horizonte',3106200),(4,4,'Vitória',3205309),(5,5,'Porto Alegre',4314902),(6,6,'Florianópolis',4205407),(7,7,'Curitiba',4106902),(8,8,'Salvador',2927408),(9,9,'Recife',2611606),(10,10,'Fortaleza',2304400),(11,11,'Belém',1501402),(12,12,'Manaus',1302603),(13,13,'São Luís',2111300),(14,14,'Goiânia',5208707),(15,15,'Cuiabá',5103403),(16,1,'São Paulo',3550308),(17,2,'Rio de Janeiro',3304557),(18,3,'Belo Horizonte',3106200),(53,8,'Feira de santana',2455701),(54,8,'Feira de santana',24455701),(55,8,'Dias Davila',2332701),(56,8,'Santana',2445001);
/*!40000 ALTER TABLE `cidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `situacao_for_cli_id` int DEFAULT NULL,
  `id_empresa` int DEFAULT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `CPF_CNPJ` varchar(25) DEFAULT NULL,
  `RG` varchar(20) DEFAULT NULL,
  `ORG_RG` varchar(10) DEFAULT NULL,
  `inscricao_Estadual` varchar(30) DEFAULT NULL,
  `Inscricao_municipal` varchar(30) DEFAULT NULL,
  `desde` date DEFAULT NULL,
  `tipo_pessoa` char(1) DEFAULT NULL,
  `EXCLUIDO` char(1) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `situacao_for_cli_id` (`situacao_for_cli_id`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresa` (`id`),
  CONSTRAINT `cliente_ibfk_2` FOREIGN KEY (`situacao_for_cli_id`) REFERENCES `situacao_for_cli` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,1,1,'Cliente 1','11111111111','123456789','SSP','12345678','87654321','2020-01-01','F','N','2020-01-01'),(2,2,2,'Cliente 2','22222222222','234567890','SSP','23456789','98765432','2020-02-01','J','N','2020-02-01'),(3,3,3,'Cliente 3','33333333333','345678901','SSP','34567890','87654321','2020-03-01','F','N','2020-03-01'),(4,4,4,'Cliente 4','44444444444','456789012','SSP','45678901','98765432','2020-04-01','J','N','2020-04-01'),(5,5,5,'Cliente 5','55555555555','567890123','SSP','56789012','87654321','2020-05-01','F','N','2020-05-01'),(6,6,6,'Cliente 6','66666666666','678901234','SSP','67890123','98765432','2020-06-01','J','N','2020-06-01'),(7,7,7,'Cliente 7','77777777777','789012345','SSP','78901234','87654321','2020-07-01','F','N','2020-07-01'),(8,8,8,'Cliente 8','88888888888','890123456','SSP','89012345','98765432','2020-08-01','J','N','2020-08-01'),(9,9,9,'Cliente 9','99999999999','901234567','SSP','90123456','87654321','2020-09-01','F','N','2020-09-01'),(10,10,10,'Cliente 10','10101010101','012345678','SSP','01234567','98765432','2020-10-01','J','N','2020-10-01'),(11,11,11,'Cliente 11','11111111111','123456789','SSP','12345678','87654321','2020-11-01','F','N','2020-11-01'),(12,12,12,'Cliente 12','12121212121','234567890','SSP','23456789','98765432','2020-12-01','J','N','2020-12-01'),(13,13,13,'Cliente 13','13131313131','345678901','SSP','34567890','87654321','2021-01-01','F','N','2021-01-01'),(14,14,14,'Cliente 14','14141414141','456789012','SSP','45678901','98765432','2021-02-01','J','N','2021-02-01'),(15,15,15,'Cliente 15','15151515151','567890123','SSP','56789012','87654321','2021-03-01','F','N','2021-03-01');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador`
--

DROP TABLE IF EXISTS `colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colaborador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nivel_formacao_id` int DEFAULT NULL,
  `tipo_colaborador_id` int DEFAULT NULL,
  `cargo_id` int DEFAULT NULL,
  `id_setor` int DEFAULT NULL,
  `nome_colaborador` varchar(140) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `orgao_rg` varchar(20) DEFAULT NULL,
  `dataNascimento` date DEFAULT NULL,
  `tipo_sanguineo` varchar(25) DEFAULT NULL,
  `foto_34` varchar(20) DEFAULT NULL,
  `excluido` char(1) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nivel_formacao_id` (`nivel_formacao_id`),
  KEY `tipo_colaborador_id` (`tipo_colaborador_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `id_setor` (`id_setor`),
  CONSTRAINT `colaborador_ibfk_1` FOREIGN KEY (`nivel_formacao_id`) REFERENCES `nivel_formacao` (`id`),
  CONSTRAINT `colaborador_ibfk_2` FOREIGN KEY (`tipo_colaborador_id`) REFERENCES `tipo_colaborador` (`id`),
  CONSTRAINT `colaborador_ibfk_3` FOREIGN KEY (`cargo_id`) REFERENCES `cargo` (`id`),
  CONSTRAINT `colaborador_ibfk_4` FOREIGN KEY (`id_setor`) REFERENCES `setor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador`
--

LOCK TABLES `colaborador` WRITE;
/*!40000 ALTER TABLE `colaborador` DISABLE KEYS */;
INSERT INTO `colaborador` VALUES (1,1,1,1,1,'Colaborador 1','11111111111','123456789','SSP','1980-01-01','O+','foto1.jpg','N','2020-01-01'),(2,2,2,2,2,'Colaborador 2','22222222222','234567890','SSP','1981-02-01','A+','foto2.jpg','N','2020-02-01'),(3,3,3,3,3,'Colaborador 3','33333333333','345678901','SSP','1982-03-01','B+','foto3.jpg','N','2020-03-01'),(4,4,4,4,4,'Colaborador 4','44444444444','456789012','SSP','1983-04-01','AB+','foto4.jpg','N','2020-04-01'),(5,5,5,5,5,'Colaborador 5','55555555555','567890123','SSP','1984-05-01','O-','foto5.jpg','N','2020-05-01'),(6,6,6,6,6,'Colaborador 6','66666666666','678901234','SSP','1985-06-01','A-','foto6.jpg','N','2020-06-01'),(7,7,7,7,7,'Colaborador 7','77777777777','789012345','SSP','1986-07-01','B-','foto7.jpg','N','2020-07-01'),(8,8,8,8,8,'Colaborador 8','88888888888','890123456','SSP','1987-08-01','AB-','foto8.jpg','N','2020-08-01'),(9,9,9,9,9,'Colaborador 9','99999999999','901234567','SSP','1988-09-01','O+','foto9.jpg','N','2020-09-01'),(10,10,10,10,10,'Colaborador 10','10101010101','012345678','SSP','1989-10-01','A+','foto10.jpg','N','2020-10-01'),(11,11,11,11,11,'Colaborador 11','11111111111','123456789','SSP','1990-11-01','B+','foto11.jpg','N','2020-11-01'),(12,12,12,12,12,'Colaborador 12','12121212121','234567890','SSP','1991-12-01','AB+','foto12.jpg','N','2020-12-01'),(13,13,13,13,13,'Colaborador 13','13131313131','345678901','SSP','1992-01-01','O-','foto13.jpg','N','2021-01-01'),(14,14,14,14,14,'Colaborador 14','14141414141','456789012','SSP','1993-02-01','A-','foto14.jpg','N','2021-02-01'),(15,15,15,15,15,'Colaborador 15','15151515151','567890123','SSP','1994-03-01','B-','foto15.jpg','N','2021-03-01');
/*!40000 ALTER TABLE `colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador_relacionamento`
--

DROP TABLE IF EXISTS `colaborador_relacionamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colaborador_relacionamento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_relacionamento_id` int DEFAULT NULL,
  `colaborador_id` int DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipo_relacionamento_id` (`tipo_relacionamento_id`),
  KEY `colaborador_id` (`colaborador_id`),
  CONSTRAINT `colaborador_relacionamento_ibfk_1` FOREIGN KEY (`tipo_relacionamento_id`) REFERENCES `tipo_relacionamento` (`id`),
  CONSTRAINT `colaborador_relacionamento_ibfk_2` FOREIGN KEY (`colaborador_id`) REFERENCES `colaborador` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador_relacionamento`
--

LOCK TABLES `colaborador_relacionamento` WRITE;
/*!40000 ALTER TABLE `colaborador_relacionamento` DISABLE KEYS */;
INSERT INTO `colaborador_relacionamento` VALUES (1,1,1,'Relacionamento 1'),(2,2,2,'Relacionamento 2'),(3,3,3,'Relacionamento 3'),(4,4,4,'Relacionamento 4'),(5,5,5,'Relacionamento 5'),(6,6,6,'Relacionamento 6'),(7,7,7,'Relacionamento 7'),(8,8,8,'Relacionamento 8'),(9,9,9,'Relacionamento 9'),(10,10,10,'Relacionamento 10'),(11,11,11,'Relacionamento 11'),(12,12,12,'Relacionamento 12'),(13,13,13,'Relacionamento 13'),(14,14,14,'Relacionamento 14'),(15,15,15,'Relacionamento 15');
/*!40000 ALTER TABLE `colaborador_relacionamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato`
--

DROP TABLE IF EXISTS `contato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `EMPRESA_ID` int DEFAULT NULL,
  `COLABORADOR_ID` int DEFAULT NULL,
  `CLIENTE_ID` int DEFAULT NULL,
  `FORNECEDOR_ID` int DEFAULT NULL,
  `NOME_CONTATO` varchar(120) DEFAULT NULL,
  `DONO` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `EMPRESA_ID` (`EMPRESA_ID`),
  KEY `COLABORADOR_ID` (`COLABORADOR_ID`),
  KEY `CLIENTE_ID` (`CLIENTE_ID`),
  KEY `FORNECEDOR_ID` (`FORNECEDOR_ID`),
  CONSTRAINT `contato_ibfk_1` FOREIGN KEY (`EMPRESA_ID`) REFERENCES `empresa` (`id`),
  CONSTRAINT `contato_ibfk_2` FOREIGN KEY (`COLABORADOR_ID`) REFERENCES `colaborador` (`id`),
  CONSTRAINT `contato_ibfk_3` FOREIGN KEY (`CLIENTE_ID`) REFERENCES `cliente` (`id`),
  CONSTRAINT `contato_ibfk_4` FOREIGN KEY (`FORNECEDOR_ID`) REFERENCES `fornecedor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato`
--

LOCK TABLES `contato` WRITE;
/*!40000 ALTER TABLE `contato` DISABLE KEYS */;
INSERT INTO `contato` VALUES (1,1,1,1,1,'Contato 1','N'),(2,2,2,2,2,'Contato 2','N'),(3,3,3,3,3,'Contato 3','N'),(4,4,4,4,4,'Contato 4','N'),(5,5,5,5,5,'Contato 5','N'),(6,6,6,6,6,'Contato 6','N'),(7,7,7,7,7,'Contato 7','N'),(8,8,8,8,8,'Contato 8','N'),(9,9,9,9,9,'Contato 9','N'),(10,10,10,10,10,'Contato 10','N'),(11,11,11,11,11,'Contato 11','N'),(12,12,12,12,12,'Contato 12','N'),(13,13,13,13,13,'Contato 13','N'),(14,14,14,14,14,'Contato 14','N'),(15,15,15,15,15,'Contato 15','N');
/*!40000 ALTER TABLE `contato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato_email`
--

DROP TABLE IF EXISTS `contato_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_email_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipo_email_id` (`tipo_email_id`),
  KEY `contato_id` (`contato_id`),
  CONSTRAINT `contato_email_ibfk_1` FOREIGN KEY (`tipo_email_id`) REFERENCES `tipo_email` (`id`),
  CONSTRAINT `contato_email_ibfk_2` FOREIGN KEY (`contato_id`) REFERENCES `contato` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato_email`
--

LOCK TABLES `contato_email` WRITE;
/*!40000 ALTER TABLE `contato_email` DISABLE KEYS */;
INSERT INTO `contato_email` VALUES (1,1,1,'email1@example.com'),(2,2,2,'email2@example.com'),(3,3,3,'email3@example.com'),(4,4,4,'email4@example.com'),(5,5,5,'email5@example.com'),(6,6,6,'email6@example.com'),(7,7,7,'email7@example.com'),(8,8,8,'email8@example.com'),(9,9,9,'email9@example.com'),(10,10,10,'email10@example.com'),(11,11,11,'email11@example.com'),(12,12,12,'email12@example.com'),(13,13,13,'email13@example.com'),(14,14,14,'email14@example.com'),(15,15,15,'email15@example.com');
/*!40000 ALTER TABLE `contato_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contato_telefone`
--

DROP TABLE IF EXISTS `contato_telefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contato_telefone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_telefone_id` int DEFAULT NULL,
  `contato_id` int DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipo_telefone_id` (`tipo_telefone_id`),
  KEY `contato_id` (`contato_id`),
  CONSTRAINT `contato_telefone_ibfk_1` FOREIGN KEY (`tipo_telefone_id`) REFERENCES `tipo_telefone` (`id`),
  CONSTRAINT `contato_telefone_ibfk_2` FOREIGN KEY (`contato_id`) REFERENCES `contato` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contato_telefone`
--

LOCK TABLES `contato_telefone` WRITE;
/*!40000 ALTER TABLE `contato_telefone` DISABLE KEYS */;
INSERT INTO `contato_telefone` VALUES (1,1,1,'1111111111'),(2,2,2,'2222222222'),(3,3,3,'3333333333'),(4,4,4,'4444444444'),(5,5,5,'5555555555'),(6,6,6,'6666666666'),(7,7,7,'7777777777'),(8,8,8,'8888888888'),(9,9,9,'9999999999'),(10,10,10,'1010101010'),(11,11,11,'1111111111'),(12,12,12,'1212121212'),(13,13,13,'1313131313'),(14,14,14,'1414141414'),(15,15,15,'1515151515');
/*!40000 ALTER TABLE `contato_telefone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `convenio`
--

DROP TABLE IF EXISTS `convenio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `convenio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_Empresa` int DEFAULT NULL,
  `nome` varchar(1000) DEFAULT NULL,
  `descricao` text,
  `desconto` double DEFAULT NULL,
  `data_Vencimento` date DEFAULT NULL,
  `endereco` varchar(250) DEFAULT NULL,
  `contato` varchar(30) DEFAULT NULL,
  `telefone` varchar(10) DEFAULT NULL,
  `Excluido` char(1) DEFAULT NULL,
  `data_Cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_Empresa` (`id_Empresa`),
  CONSTRAINT `convenio_ibfk_1` FOREIGN KEY (`id_Empresa`) REFERENCES `empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `convenio`
--

LOCK TABLES `convenio` WRITE;
/*!40000 ALTER TABLE `convenio` DISABLE KEYS */;
INSERT INTO `convenio` VALUES (1,1,'Convenio 1','Descrição do Convenio 1',0.1,'2024-06-01','Endereço do Convenio 1','Contato 1','1234567890','N','2024-05-22'),(2,2,'Convenio 2','Descrição do Convenio 2',0.2,'2024-06-02','Endereço do Convenio 2','Contato 2','2345678901','N','2024-05-22'),(3,3,'Convenio 3','Descrição do Convenio 3',0.3,'2024-06-03','Endereço do Convenio 3','Contato 3','3456789012','N','2024-05-22'),(4,4,'Convenio 4','Descrição do Convenio 4',0.4,'2024-06-04','Endereço do Convenio 4','Contato 4','4567890123','N','2024-05-22'),(5,5,'Convenio 5','Descrição do Convenio 5',0.5,'2024-06-05','Endereço do Convenio 5','Contato 5','5678901234','N','2024-05-22'),(6,6,'Convenio 6','Descrição do Convenio 6',0.6,'2024-06-06','Endereço do Convenio 6','Contato 6','6789012345','N','2024-05-22'),(7,7,'Convenio 7','Descrição do Convenio 7',0.7,'2024-06-07','Endereço do Convenio 7','Contato 7','7890123456','N','2024-05-22'),(8,8,'Convenio 8','Descrição do Convenio 8',0.8,'2024-06-08','Endereço do Convenio 8','Contato 8','8901234567','N','2024-05-22'),(9,9,'Convenio 9','Descrição do Convenio 9',0.9,'2024-06-09','Endereço do Convenio 9','Contato 9','9012345678','N','2024-05-22'),(10,10,'Convenio 10','Descrição do Convenio 10',0.1,'2024-06-10','Endereço do Convenio 10','Contato 10','0123456789','N','2024-05-22'),(11,11,'Convenio 11','Descrição do Convenio 11',0.11,'2024-06-11','Endereço do Convenio 11','Contato 11','1234567890','N','2024-05-22'),(12,12,'Convenio 12','Descrição do Convenio 12',0.12,'2024-06-12','Endereço do Convenio 12','Contato 12','2345678901','N','2024-05-22'),(13,13,'Convenio 13','Descrição do Convenio 13',0.13,'2024-06-13','Endereço do Convenio 13','Contato 13','3456789012','N','2024-05-22'),(14,14,'Convenio 14','Descrição do Convenio 14',0.14,'2024-06-14','Endereço do Convenio 14','Contato 14','4567890123','N','2024-05-22'),(15,15,'Convenio 15','Descrição do Convenio 15',0.15,'2024-06-15','Endereço do Convenio 15','Contato 15','5678901234','N','2024-05-22');
/*!40000 ALTER TABLE `convenio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `empresa_id` int DEFAULT NULL,
  `razao_social` varchar(80) DEFAULT NULL,
  `nome_fantasia` varchar(100) DEFAULT NULL,
  `CNPJ` varchar(25) DEFAULT NULL,
  `inscricao_Estadual` varchar(30) DEFAULT NULL,
  `Inscricao_municipal` varchar(30) DEFAULT NULL,
  `matriz_filial` char(1) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (1,1,'Empresa A Ltda','Empresa A','12345678000101','123456789','987654321','M','2023-01-01'),(2,2,'Empresa B Ltda','Empresa B','23456789000112','234567890','876543210','F','2023-01-01'),(3,3,'Empresa C Ltda','Empresa C','34567890000123','345678901','765432109','M','2023-01-01'),(4,4,'Empresa D Ltda','Empresa D','45678900001234','456789012','654321098','F','2023-01-01'),(5,5,'Empresa E Ltda','Empresa E','56789000012345','567890123','543210987','M','2023-01-01'),(6,6,'Empresa F Ltda','Empresa F','67890000123456','678901234','432109876','F','2023-01-01'),(7,7,'Empresa G Ltda','Empresa G','78900001234567','789012345','321098765','M','2023-01-01'),(8,8,'Empresa H Ltda','Empresa H','89000012345678','890123456','210987654','F','2023-01-01'),(9,9,'Empresa I Ltda','Empresa I','90000123456789','901234567','109876543','M','2023-01-01'),(10,10,'Empresa J Ltda','Empresa J','10001234567890','012345678','098765432','F','2023-01-01'),(11,11,'Empresa K Ltda','Empresa K','11012345678901','123456789','987654321','M','2023-01-01'),(12,12,'Empresa L Ltda','Empresa L','12023456789012','234567890','876543210','F','2023-01-01'),(13,13,'Empresa M Ltda','Empresa M','13034567890123','345678901','765432109','M','2023-01-01'),(14,14,'Empresa N Ltda','Empresa N','14045678901234','456789012','654321098','F','2023-01-01'),(15,15,'Empresa O Ltda','Empresa O','15056789012345','567890123','543210987','M','2023-01-01');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa_produto`
--

DROP TABLE IF EXISTS `empresa_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `empresa_id` int DEFAULT NULL,
  `produto_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empresa_id` (`empresa_id`),
  KEY `produto_id` (`produto_id`),
  CONSTRAINT `empresa_produto_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`),
  CONSTRAINT `empresa_produto_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa_produto`
--

LOCK TABLES `empresa_produto` WRITE;
/*!40000 ALTER TABLE `empresa_produto` DISABLE KEYS */;
INSERT INTO `empresa_produto` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(23,1,19),(30,NULL,27);
/*!40000 ALTER TABLE `empresa_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `endereco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `empresa_id` int DEFAULT NULL,
  `colaborador_id` int DEFAULT NULL,
  `fornecedor_id` int DEFAULT NULL,
  `cliente_id` int DEFAULT NULL,
  `tipo_endereco_id` int DEFAULT NULL,
  `cep_id` int DEFAULT NULL,
  `logradouro` varchar(100) DEFAULT NULL,
  `numero` int DEFAULT NULL,
  `complemento` varchar(50) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `dono` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empresa_id` (`empresa_id`),
  KEY `colaborador_id` (`colaborador_id`),
  KEY `fornecedor_id` (`fornecedor_id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `cep_id` (`cep_id`),
  KEY `tipo_endereco_id` (`tipo_endereco_id`),
  CONSTRAINT `endereco_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`),
  CONSTRAINT `endereco_ibfk_2` FOREIGN KEY (`colaborador_id`) REFERENCES `colaborador` (`id`),
  CONSTRAINT `endereco_ibfk_3` FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedor` (`id`),
  CONSTRAINT `endereco_ibfk_4` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `endereco_ibfk_5` FOREIGN KEY (`cep_id`) REFERENCES `cep` (`id`),
  CONSTRAINT `endereco_ibfk_6` FOREIGN KEY (`tipo_endereco_id`) REFERENCES `tipo_endereco` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco`
--

LOCK TABLES `endereco` WRITE;
/*!40000 ALTER TABLE `endereco` DISABLE KEYS */;
INSERT INTO `endereco` VALUES (1,1,1,1,1,1,1,'Rua 1',101,'Apto 1','Bairro 1','N'),(2,2,2,2,2,2,2,'Rua 2',102,'Apto 2','Bairro 2','N'),(3,3,3,3,3,3,3,'Rua 3',103,'Apto 3','Bairro 3','N'),(4,4,4,4,4,4,4,'Rua 4',104,'Apto 4','Bairro 4','N'),(5,5,5,5,5,5,5,'Rua 5',105,'Apto 5','Bairro 5','N'),(6,6,6,6,6,6,6,'Rua 6',106,'Apto 6','Bairro 6','N'),(7,7,7,7,7,7,7,'Rua 7',107,'Apto 7','Bairro 7','N'),(8,8,8,8,8,8,8,'Rua 8',108,'Apto 8','Bairro 8','N'),(9,9,9,9,9,9,9,'Rua 9',109,'Apto 9','Bairro 9','N'),(10,10,10,10,10,10,10,'Rua 10',110,'Apto 10','Bairro 10','N'),(11,11,11,11,11,11,11,'Rua 11',111,'Apto 11','Bairro 11','N'),(12,12,12,12,12,12,12,'Rua 12',112,'Apto 12','Bairro 12','N'),(13,13,13,13,13,13,13,'Rua 13',113,'Apto 13','Bairro 13','N'),(14,14,14,14,14,14,14,'Rua 14',114,'Apto 14','Bairro 14','N'),(15,15,15,15,15,15,15,'Rua 15',115,'Apto 15','Bairro 15','N');
/*!40000 ALTER TABLE `endereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pais_id` int DEFAULT NULL,
  `sigla` char(2) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `codigo_IBGE` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pais_id` (`pais_id`),
  CONSTRAINT `estado_ibfk_1` FOREIGN KEY (`pais_id`) REFERENCES `pais` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

LOCK TABLES `estado` WRITE;
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` VALUES (1,1,'SP','São Paulo',35),(2,1,'RJ','Rio de Janeiro',33),(3,1,'MG','Minas Gerais',31),(4,1,'ES','Espírito Santo',32),(5,1,'RS','Rio Grande do Sul',43),(6,1,'SC','Santa Catarina',42),(7,1,'PR','Paraná',41),(8,1,'BA','Bahia',29),(9,1,'PE','Pernambuco',26),(10,1,'CE','Ceará',23),(11,1,'PA','Pará',15),(12,1,'AM','Amazonas',13),(13,1,'MA','Maranhão',21),(14,1,'GO','Goiás',52),(15,1,'MT','Mato Grosso',51);
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fornecedor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo_fornecedor_id` int DEFAULT NULL,
  `situacao_for_cli_id` int DEFAULT NULL,
  `id_empresa` int DEFAULT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `CPF_CNPJ` varchar(25) DEFAULT NULL,
  `RG` varchar(20) DEFAULT NULL,
  `ORGAO_RG` varchar(10) DEFAULT NULL,
  `inscricao_Estadual` varchar(20) DEFAULT NULL,
  `Inscricao_municipal` varchar(20) DEFAULT NULL,
  `desde` date DEFAULT NULL,
  `tipo_pessoa` char(1) DEFAULT NULL,
  `excluido` char(1) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `tipo_fornecedor_id` (`tipo_fornecedor_id`),
  KEY `situacao_for_cli_id` (`situacao_for_cli_id`),
  CONSTRAINT `fornecedor_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresa` (`id`),
  CONSTRAINT `fornecedor_ibfk_2` FOREIGN KEY (`tipo_fornecedor_id`) REFERENCES `fornecedor` (`id`),
  CONSTRAINT `fornecedor_ibfk_3` FOREIGN KEY (`situacao_for_cli_id`) REFERENCES `situacao_for_cli` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedor`
--

LOCK TABLES `fornecedor` WRITE;
/*!40000 ALTER TABLE `fornecedor` DISABLE KEYS */;
INSERT INTO `fornecedor` VALUES (1,1,1,1,'Fornecedor 1','11111111111','123456789','SSP','12345678','87654321','2020-01-01','F','N','2020-01-01'),(2,2,2,2,'Fornecedor 2','22222222222','234567890','SSP','23456789','98765432','2020-02-01','J','N','2020-02-01'),(3,3,3,3,'Fornecedor 3','33333333333','345678901','SSP','34567890','87654321','2020-03-01','F','N','2020-03-01'),(4,4,4,4,'Fornecedor 4','44444444444','456789012','SSP','45678901','98765432','2020-04-01','J','N','2020-04-01'),(5,5,5,5,'Fornecedor 5','55555555555','567890123','SSP','56789012','87654321','2020-05-01','F','N','2020-05-01'),(6,6,6,6,'Fornecedor 6','66666666666','678901234','SSP','67890123','98765432','2020-06-01','J','N','2020-06-01'),(7,7,7,7,'Fornecedor 7','77777777777','789012345','SSP','78901234','87654321','2020-07-01','F','N','2020-07-01'),(8,8,8,8,'Fornecedor 8','88888888888','890123456','SSP','89012345','98765432','2020-08-01','J','N','2020-08-01'),(9,9,9,9,'Fornecedor 9','99999999999','901234567','SSP','90123456','87654321','2020-09-01','F','N','2020-09-01'),(10,10,10,10,'Fornecedor 10','10101010101','012345678','SSP','01234567','98765432','2020-10-01','J','N','2020-10-01'),(11,11,11,11,'Fornecedor 11','11111111111','123456789','SSP','12345678','87654321','2020-11-01','F','N','2020-11-01'),(12,12,12,12,'Fornecedor 12','12121212121','234567890','SSP','23456789','98765432','2020-12-01','J','N','2020-12-01'),(13,13,13,13,'Fornecedor 13','13131313131','345678901','SSP','34567890','87654321','2021-01-01','F','N','2021-01-01'),(14,14,14,14,'Fornecedor 14','14141414141','456789012','SSP','45678901','98765432','2021-02-01','J','N','2021-02-01'),(15,15,15,15,'Fornecedor 15','15151515151','567890123','SSP','56789012','87654321','2021-03-01','F','N','2021-03-01');
/*!40000 ALTER TABLE `fornecedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornecedor_produto`
--

DROP TABLE IF EXISTS `fornecedor_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fornecedor_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fornecedor_id` int DEFAULT NULL,
  `produto_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fornecedor_id` (`fornecedor_id`),
  KEY `produto_id` (`produto_id`),
  CONSTRAINT `fornecedor_produto_ibfk_1` FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedor` (`id`),
  CONSTRAINT `fornecedor_produto_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedor_produto`
--

LOCK TABLES `fornecedor_produto` WRITE;
/*!40000 ALTER TABLE `fornecedor_produto` DISABLE KEYS */;
INSERT INTO `fornecedor_produto` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15);
/*!40000 ALTER TABLE `fornecedor_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcao`
--

DROP TABLE IF EXISTS `funcao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao_menu` text,
  `imagem_menu` varchar(30) DEFAULT NULL,
  `metodo` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcao`
--

LOCK TABLES `funcao` WRITE;
/*!40000 ALTER TABLE `funcao` DISABLE KEYS */;
INSERT INTO `funcao` VALUES (1,'Gerenciar Produtos','gerenciar_produtos.png','gerenciarProdutos'),(2,'Vendas','vendas.png','realizarVendas'),(3,'Relatórios','relatorios.png','gerarRelatorios'),(4,'Configurações','configuracoes.png','ajustarConfiguracoes'),(5,'Usuários','usuarios.png','gerenciarUsuarios'),(6,'Financeiro','financeiro.png','controleFinanceiro'),(7,'Estoque','estoque.png','gerenciarEstoque'),(8,'Fornecedores','fornecedores.png','gerenciarFornecedores'),(9,'Clientes','clientes.png','gerenciarClientes'),(10,'Marketing','marketing.png','gerenciarMarketing'),(11,'RH','rh.png','gestaoRH'),(12,'Help Desk','help_desk.png','suporteTecnico'),(13,'Auditoria','auditoria.png','auditarSistemas'),(14,'Compliance','compliance.png','verificarCompliance'),(15,'Projetos','projetos.png','gerenciarProjetos'),(16,'Menu Principal','menu_principal.png','GET'),(17,'Perfil do Usuário','perfil_usuario.png','GET'),(19,'Home','home.png','GET'),(21,'home','notificacoes.Jpg','Gerenciamento'),(22,'casa','casa.jpg','postegree');
/*!40000 ALTER TABLE `funcao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupo_produto`
--

DROP TABLE IF EXISTS `grupo_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grupo_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupo_produto`
--

LOCK TABLES `grupo_produto` WRITE;
/*!40000 ALTER TABLE `grupo_produto` DISABLE KEYS */;
INSERT INTO `grupo_produto` VALUES (1,'Bebidas','Todos os tipos de bebidas'),(2,'Alimentos','Produtos alimentícios'),(3,'Limpeza','Produtos de limpeza'),(4,'Higiene Pessoal','Produtos para higiene pessoal'),(5,'Eletrônicos','Dispositivos eletrônicos e acessórios'),(6,'Roupas','Vestuário e acessórios'),(7,'Móveis','Móveis para casa e escritório'),(8,'Papelaria','Artigos de papelaria'),(9,'Brinquedos','Brinquedos para crianças'),(10,'Ferramentas','Ferramentas e equipamentos'),(11,'Automotivo','Produtos para veículos'),(12,'Esportes','Artigos esportivos'),(13,'Jardinagem','Produtos para jardinagem'),(14,'Cosméticos','Produtos de beleza e cosméticos'),(15,'Farmácia','Medicamentos e produtos farmacêuticos');
/*!40000 ALTER TABLE `grupo_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indice_economico`
--

DROP TABLE IF EXISTS `indice_economico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `indice_economico` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pais_id` int DEFAULT NULL,
  `sigla` varchar(30) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`),
  KEY `pais_id` (`pais_id`),
  CONSTRAINT `indice_economico_ibfk_1` FOREIGN KEY (`pais_id`) REFERENCES `pais` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indice_economico`
--

LOCK TABLES `indice_economico` WRITE;
/*!40000 ALTER TABLE `indice_economico` DISABLE KEYS */;
INSERT INTO `indice_economico` VALUES (1,1,'PIB','Produto Interno Bruto','Mede a soma de todos os bens e serviços finais produzidos em um país.'),(2,2,'IPC','Índice de Preços ao Consumidor','Mede a variação de preços de uma cesta de bens e serviços.'),(3,3,'IGP-M','Índice Geral de Preços - Mercado','Mede a variação de preços de uma cesta de bens e serviços, abrangendo diferentes setores da economia.'),(4,4,'IPCA','Índice de Preços ao Consumidor Amplo','Mede a variação de preços de uma cesta de bens e serviços, utilizada para medir a inflação.'),(5,5,'Selic','Taxa Selic','Taxa básica de juros da economia brasileira.'),(6,6,'CDI','Certificado de Depósito Interbancário','Taxa de juros praticada entre os bancos.'),(7,7,'Poupança','Taxa de Juros da Poupança','Taxa de juros aplicada aos depósitos em poupança.'),(8,8,'Câmbio','Taxa de Câmbio','Taxa de conversão entre duas moedas.'),(9,9,'INPC','Índice Nacional de Preços ao Consumidor','Mede a variação de preços de uma cesta de bens e serviços para famílias com rendimento até 5 salários mínimos.'),(10,10,'FGV','Fundação Getulio Vargas','Mede a variação de preços de bens e serviços, através de índices próprios.'),(11,11,'IPC-Fipe','Índice de Preços ao Consumidor - Fipe','Mede a variação de preços de uma cesta de bens e serviços na cidade de São Paulo.'),(12,12,'INCC','Índice Nacional de Custo da Construção','Mede a variação dos custos da construção civil.'),(13,13,'IGP-DI','Índice Geral de Preços - Disponibilidade Interna','Mede a variação de preços de uma cesta de bens e serviços no mercado interno.'),(14,14,'IPA','Índice de Preços ao Produtor Amplo','Mede a variação de preços no atacado.'),(15,15,'IPCA-15','Índice de Preços ao Consumidor Amplo 15','Mede a variação de preços de uma cesta de bens e serviços, utilizado como prévia do IPCA.');
/*!40000 ALTER TABLE `indice_economico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_cidade`
--

DROP TABLE IF EXISTS `log_cidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_cidade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Operacao` varchar(20) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `codigo_IBGE` int DEFAULT NULL,
  `data_modificacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_tabela` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_cidade`
--

LOCK TABLES `log_cidade` WRITE;
/*!40000 ALTER TABLE `log_cidade` DISABLE KEYS */;
INSERT INTO `log_cidade` VALUES (1,'Update Antigo','São Paulo',3550308,'2024-05-22 23:39:06',1),(2,'Update','Mata de São João',2921008,'2024-05-22 23:39:06',1),(52,'Delete','Camaçari',2905701,'2024-05-22 23:44:27',NULL),(53,'Insert','Dias Davila',2332701,'2024-05-23 00:45:20',NULL),(54,'Insert','Santana',2445001,'2024-05-23 00:49:18',NULL);
/*!40000 ALTER TABLE `log_cidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_funcao`
--

DROP TABLE IF EXISTS `log_funcao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_funcao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Operacao` varchar(20) DEFAULT NULL,
  `descricao_menu` varchar(100) DEFAULT NULL,
  `imagem_menu` varchar(50) DEFAULT NULL,
  `metodo` varchar(50) DEFAULT NULL,
  `data_modificacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_tabela` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_funcao`
--

LOCK TABLES `log_funcao` WRITE;
/*!40000 ALTER TABLE `log_funcao` DISABLE KEYS */;
INSERT INTO `log_funcao` VALUES (1,'Update Antigo','Notificações','notificacoes.png','GET','2024-05-23 00:37:24',21),(2,'Update','home','notificacoes.Jpg','Gerenciamento','2024-05-23 00:37:24',0),(3,'Insert','casa','casa.jpg','postegree','2024-05-23 00:38:25',0),(4,'Delete','Sair','sair.png','POST','2024-05-23 00:39:04',18);
/*!40000 ALTER TABLE `log_funcao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_tipo_email`
--

DROP TABLE IF EXISTS `log_tipo_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_tipo_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Operacao` varchar(20) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  `data_modificacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_tabela` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_tipo_email`
--

LOCK TABLES `log_tipo_email` WRITE;
/*!40000 ALTER TABLE `log_tipo_email` DISABLE KEYS */;
INSERT INTO `log_tipo_email` VALUES (1,'Update Antigo','Pessoal','Email pessoal do colaborador','2024-05-22 22:45:28',1),(2,'Update','Interpessoal','Email pessoal do colaborador','2024-05-22 22:45:28',1),(20,'Delete','Follow-up','Email de acompanhamento após uma interação anterior','2024-05-22 22:55:28',NULL),(45,'Insert','Feedbacck','E-mails utilizados para promover  serviços.','2024-05-22 23:54:23',NULL);
/*!40000 ALTER TABLE `log_tipo_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nivel_formacao`
--

DROP TABLE IF EXISTS `nivel_formacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nivel_formacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nivel_formacao`
--

LOCK TABLES `nivel_formacao` WRITE;
/*!40000 ALTER TABLE `nivel_formacao` DISABLE KEYS */;
INSERT INTO `nivel_formacao` VALUES (1,'Ensino Fundamental','Ensino fundamental completo'),(2,'Ensino Médio','Ensino médio completo'),(3,'Técnico','Curso técnico'),(4,'Tecnólogo','Curso tecnólogo'),(5,'Superior','Ensino superior completo'),(6,'Pós-Graduação','Pós-graduação'),(7,'Mestrado','Curso de mestrado'),(8,'Doutorado','Curso de doutorado'),(9,'MBA','Master in Business Administration'),(10,'PhD','Doctor of Philosophy'),(11,'Curso Livre','Cursos livres e complementares'),(12,'Ensino a Distância','Ensino a distância'),(13,'Intercâmbio','Cursos realizados no exterior'),(14,'Capacitação','Capacitação profissional'),(15,'Treinamento','Treinamento interno');
/*!40000 ALTER TABLE `nivel_formacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operadora_cartao`
--

DROP TABLE IF EXISTS `operadora_cartao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operadora_cartao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bandeira` varchar(30) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operadora_cartao`
--

LOCK TABLES `operadora_cartao` WRITE;
/*!40000 ALTER TABLE `operadora_cartao` DISABLE KEYS */;
INSERT INTO `operadora_cartao` VALUES (1,'Visa','Visa Inc.'),(2,'MasterCard','MasterCard Worldwide'),(3,'American Express','American Express Company'),(4,'Elo','Elo Serviços S.A.'),(5,'Hipercard','Banco Itaú S.A.'),(6,'Diners Club','Diners Club International'),(7,'Discover','Discover Financial Services'),(8,'JCB','Japan Credit Bureau'),(9,'Aura','Aura Brasil'),(10,'Cabal','Cabal Brasil'),(11,'Banese Card','Banese Card S.A.'),(12,'Sorocred','Sorocred Administradora de Cartões de Crédito'),(13,'Good Card','Good Card S.A.'),(14,'Credz','Credz Administradora de Cartões de Crédito'),(15,'Avista','Avista S.A. Administradora de Cartões de Crédito');
/*!40000 ALTER TABLE `operadora_cartao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pais`
--

DROP TABLE IF EXISTS `pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pais` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` int DEFAULT NULL,
  `nome_pais` varchar(100) DEFAULT NULL,
  `sigla2` char(2) DEFAULT NULL,
  `sigla3` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pais`
--

LOCK TABLES `pais` WRITE;
/*!40000 ALTER TABLE `pais` DISABLE KEYS */;
INSERT INTO `pais` VALUES (1,1,'Brasil','BR','BRA'),(2,2,'Argentina','AR','ARG'),(3,3,'Chile','CL','CHL'),(4,4,'Uruguai','UY','URY'),(5,5,'Paraguai','PY','PRY'),(6,6,'Bolívia','BO','BOL'),(7,7,'Peru','PE','PER'),(8,8,'Colômbia','CO','COL'),(9,9,'Venezuela','VE','VEN'),(10,10,'Equador','EC','ECU'),(11,11,'Guiana','GY','GUY'),(12,12,'Suriname','SR','SUR'),(13,13,'Guiana Francesa','GF','GUF'),(14,14,'Estados Unidos','US','USA'),(15,15,'Canadá','CA','CAN');
/*!40000 ALTER TABLE `pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papel`
--

DROP TABLE IF EXISTS `papel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papel` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papel`
--

LOCK TABLES `papel` WRITE;
/*!40000 ALTER TABLE `papel` DISABLE KEYS */;
INSERT INTO `papel` VALUES (1,'Administrador','Acesso total ao sistema'),(2,'Gerente','Acesso de gerente ao sistema'),(3,'Usuário','Acesso de usuário padrão ao sistema'),(4,'Financeiro','Acesso ao módulo financeiro'),(5,'Vendas','Acesso ao módulo de vendas'),(6,'Compras','Acesso ao módulo de compras'),(7,'Estoque','Acesso ao módulo de estoque'),(8,'TI','Acesso ao módulo de tecnologia da informação'),(9,'RH','Acesso ao módulo de recursos humanos'),(10,'Marketing','Acesso ao módulo de marketing'),(11,'Suporte','Acesso ao módulo de suporte técnico'),(12,'Logística','Acesso ao módulo de logística'),(13,'Diretoria','Acesso ao módulo de diretoria'),(14,'Cliente','Acesso ao módulo de clientes'),(15,'Fornecedor','Acesso ao módulo de fornecedores');
/*!40000 ALTER TABLE `papel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papel_funcao`
--

DROP TABLE IF EXISTS `papel_funcao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `papel_funcao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `funcao_id` int DEFAULT NULL,
  `papel_id` int DEFAULT NULL,
  `pode_Consultar` char(1) DEFAULT NULL,
  `pode_Inserir` char(1) DEFAULT NULL,
  `pode_Alterar` char(1) DEFAULT NULL,
  `pode_Excluir` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `papel_id` (`papel_id`),
  KEY `funcao_id` (`funcao_id`),
  CONSTRAINT `papel_funcao_ibfk_1` FOREIGN KEY (`papel_id`) REFERENCES `papel` (`id`),
  CONSTRAINT `papel_funcao_ibfk_2` FOREIGN KEY (`funcao_id`) REFERENCES `funcao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papel_funcao`
--

LOCK TABLES `papel_funcao` WRITE;
/*!40000 ALTER TABLE `papel_funcao` DISABLE KEYS */;
INSERT INTO `papel_funcao` VALUES (1,1,1,'S','S','S','S'),(2,2,2,'S','S','S','N'),(3,3,3,'S','N','N','N'),(4,4,4,'S','S','N','N'),(5,5,5,'S','S','S','N'),(6,6,6,'S','N','N','N'),(7,7,7,'S','S','N','N'),(8,8,8,'S','N','N','N'),(9,9,9,'S','S','S','N'),(10,10,10,'S','N','N','N'),(11,11,11,'S','S','S','N'),(12,12,12,'S','N','N','N'),(13,13,13,'S','S','S','N'),(14,14,14,'S','N','N','N'),(15,15,15,'S','S','S','N');
/*!40000 ALTER TABLE `papel_funcao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_sub_grupo` int DEFAULT NULL,
  `id_unidade` int DEFAULT NULL,
  `gtin` char(15) DEFAULT NULL,
  `nome_produto` varchar(100) DEFAULT NULL,
  `descricao` text,
  `descricao_Pdv` varchar(30) DEFAULT NULL,
  `valor_compra` float(11,2) DEFAULT NULL,
  `valor_venda` float(11,2) DEFAULT NULL,
  `quant_estoque` float(11,2) DEFAULT NULL,
  `estoque_Min` float(11,2) DEFAULT NULL,
  `estoque_Max` float(11,2) DEFAULT NULL,
  `excluido` char(1) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_sub_grupo` (`id_sub_grupo`),
  KEY `id_unidade` (`id_unidade`),
  CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`id_sub_grupo`) REFERENCES `sub_grupo_produto` (`id`),
  CONSTRAINT `produto_ibfk_2` FOREIGN KEY (`id_unidade`) REFERENCES `unidade_produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,1,1,'7891001234567','Coca-Cola','Refrigerante de cola','Coca-Cola',3.00,5.00,100.00,10.00,200.00,'N','2023-01-01'),(2,1,2,'7891001234568','Guaraná Antarctica','Refrigerante de guaraná','Guaraná',2.50,4.50,150.00,15.00,250.00,'N','2023-01-01'),(3,2,1,'7891001234569','Suco de Laranja','Suco natural de laranja','Suco Laranja',2.00,3.50,80.00,5.00,150.00,'N','2023-01-01'),(4,2,2,'7891001234570','Suco de Uva','Suco natural de uva','Suco Uva',2.20,3.70,90.00,5.00,160.00,'N','2023-01-01'),(5,3,3,'7891001234571','Arroz Branco','Arroz branco tipo 1','Arroz Branco',4.00,6.00,200.00,20.00,300.00,'N','2023-01-01'),(6,3,4,'7891001234572','Feijão Preto','Feijão preto tipo 1','Feijão Preto',5.00,7.50,180.00,15.00,280.00,'N','2023-01-01'),(7,4,5,'7891001234573','Leite Integral','Leite integral 1L','Leite Integral',2.50,4.00,250.00,25.00,350.00,'N','2023-01-01'),(8,4,6,'7891001234574','Queijo Mussarela','Queijo mussarela fatiado','Queijo Mussarela',10.00,15.00,50.00,5.00,100.00,'N','2023-01-01'),(9,5,1,'7891001234575','Detergente Líquido','Detergente para lavar louças','Detergente',1.00,2.00,300.00,30.00,400.00,'N','2023-01-01'),(10,5,2,'7891001234576','Desinfetante Pinho','Desinfetante com aroma de pinho','Desinfetante Pinho',3.00,5.00,120.00,12.00,220.00,'N','2023-01-01'),(11,6,3,'7891001234577','Sabonete Líquido','Sabonete líquido 200ml','Sabonete Líquido',2.50,4.00,130.00,13.00,230.00,'N','2023-01-01'),(12,6,4,'7891001234578','Shampoo','Shampoo para cabelo normal','Shampoo',8.00,12.00,100.00,10.00,200.00,'N','2023-01-01'),(13,7,5,'7891001234579','Smartphone','Celular com 64GB de memória','Smartphone',800.00,1200.00,20.00,2.00,50.00,'N','2023-01-01'),(14,7,6,'7891001234580','Notebook','Notebook 15 polegadas','Notebook',1500.00,2200.00,15.00,1.00,30.00,'N','2023-01-01'),(15,8,1,'7891001234581','Camiseta Branca','Camiseta de algodão branca','Camiseta Branca',10.00,20.00,60.00,6.00,120.00,'N','2023-01-01'),(18,1,1,'7891000101010','Acucar','açucar cristal','Produto A',17.50,15.00,100.00,10.00,200.00,'0','2023-01-01'),(19,1,2,'7891000101010','derse A','Descrição detalhada do Produto A','Produto A',10.50,15.00,100.00,10.00,200.00,'0','2023-01-01'),(25,1,1,'7891000101210','gereat','Descrição detalhada do Produto A','Produto A',10.50,15.00,100.00,10.00,200.00,'0','2023-01-01'),(27,2,3,'7891000101210','gereat','Descrição detalhada do Produto A','Produto A',10.50,15.00,100.00,10.00,200.00,'0','2023-01-01');
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setor`
--

DROP TABLE IF EXISTS `setor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `empresa_id` int DEFAULT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`),
  KEY `empresa_id` (`empresa_id`),
  CONSTRAINT `setor_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setor`
--

LOCK TABLES `setor` WRITE;
/*!40000 ALTER TABLE `setor` DISABLE KEYS */;
INSERT INTO `setor` VALUES (1,1,'Setor A','Descrição do Setor A'),(2,2,'Setor B','Descrição do Setor B'),(3,3,'Setor C','Descrição do Setor C'),(4,4,'Setor D','Descrição do Setor D'),(5,5,'Setor E','Descrição do Setor E'),(6,6,'Setor F','Descrição do Setor F'),(7,7,'Setor G','Descrição do Setor G'),(8,8,'Setor H','Descrição do Setor H'),(9,9,'Setor I','Descrição do Setor I'),(10,10,'Setor J','Descrição do Setor J'),(11,11,'Setor K','Descrição do Setor K'),(12,12,'Setor L','Descrição do Setor L'),(13,13,'Setor M','Descrição do Setor M'),(14,14,'Setor N','Descrição do Setor N'),(15,15,'Setor O','Descrição do Setor O');
/*!40000 ALTER TABLE `setor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `situacao_for_cli`
--

DROP TABLE IF EXISTS `situacao_for_cli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `situacao_for_cli` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `situacao_for_cli`
--

LOCK TABLES `situacao_for_cli` WRITE;
/*!40000 ALTER TABLE `situacao_for_cli` DISABLE KEYS */;
INSERT INTO `situacao_for_cli` VALUES (1,'Ativo','Cliente ou fornecedor ativo'),(2,'Inativo','Cliente ou fornecedor inativo'),(3,'Bloqueado','Cliente ou fornecedor bloqueado'),(4,'Suspenso','Cliente ou fornecedor suspenso'),(5,'Cancelado','Cliente ou fornecedor cancelado'),(6,'Potencial','Cliente ou fornecedor em potencial'),(7,'Recorrente','Cliente ou fornecedor recorrente'),(8,'Ocasional','Cliente ou fornecedor ocasional'),(9,'Preferencial','Cliente ou fornecedor preferencial'),(10,'Exclusivo','Cliente ou fornecedor exclusivo'),(11,'Especial','Cliente ou fornecedor especial'),(12,'Novo','Cliente ou fornecedor novo'),(13,'Antigo','Cliente ou fornecedor antigo'),(14,'Temporário','Cliente ou fornecedor temporário'),(15,'Permanente','Cliente ou fornecedor permanente');
/*!40000 ALTER TABLE `situacao_for_cli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_grupo_produto`
--

DROP TABLE IF EXISTS `sub_grupo_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_grupo_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_grupo` int DEFAULT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`),
  KEY `id_grupo` (`id_grupo`),
  CONSTRAINT `sub_grupo_produto_ibfk_1` FOREIGN KEY (`id_grupo`) REFERENCES `grupo_produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_grupo_produto`
--

LOCK TABLES `sub_grupo_produto` WRITE;
/*!40000 ALTER TABLE `sub_grupo_produto` DISABLE KEYS */;
INSERT INTO `sub_grupo_produto` VALUES (1,1,'Refrigerantes','Bebidas gaseificadas'),(2,1,'Sucos','Sucos naturais e industrializados'),(3,2,'Cereais','Grãos e cereais diversos'),(4,2,'Laticínios','Produtos derivados do leite'),(5,3,'Detergentes','Detergentes para limpeza'),(6,3,'Desinfetantes','Produtos desinfetantes'),(7,4,'Sabonetes','Sabonetes em barra e líquido'),(8,4,'Shampoos','Produtos para lavar o cabelo'),(9,5,'Celulares','Telefones móveis e acessórios'),(10,5,'Computadores','Computadores e periféricos'),(11,6,'Camisetas','Diversos tipos de camisetas'),(12,6,'Calças','Calças de diversos materiais'),(13,7,'Cadeiras','Cadeiras para uso doméstico e comercial'),(14,7,'Mesas','Mesas de diversos tamanhos e materiais');
/*!40000 ALTER TABLE `sub_grupo_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_colaborador`
--

DROP TABLE IF EXISTS `tipo_colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_colaborador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_colaborador`
--

LOCK TABLES `tipo_colaborador` WRITE;
/*!40000 ALTER TABLE `tipo_colaborador` DISABLE KEYS */;
INSERT INTO `tipo_colaborador` VALUES (1,'Efetivo','Colaborador com contrato efetivo'),(2,'Temporário','Colaborador com contrato temporário'),(3,'Estagiário','Colaborador em regime de estágio'),(4,'Autônomo','Colaborador autônomo'),(5,'Freelancer','Colaborador freelancer'),(6,'Terceirizado','Colaborador terceirizado'),(7,'Consultor','Colaborador consultor'),(8,'Voluntário','Colaborador voluntário'),(9,'Trainee','Colaborador trainee'),(10,'Intermitente','Colaborador intermitente'),(11,'PJ','Pessoa jurídica'),(12,'Home Office','Trabalho remoto'),(13,'Part-time','Trabalho em meio período'),(14,'Full-time','Trabalho em tempo integral'),(15,'Outsourcing','Serviço terceirizado');
/*!40000 ALTER TABLE `tipo_colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_email`
--

DROP TABLE IF EXISTS `tipo_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_email` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_email`
--

LOCK TABLES `tipo_email` WRITE;
/*!40000 ALTER TABLE `tipo_email` DISABLE KEYS */;
INSERT INTO `tipo_email` VALUES (1,'Interpessoal','Email pessoal do colaborador'),(2,'Corporativo','Email corporativo do colaborador'),(3,'Financeiro','Email financeiro da empresa'),(4,'Suporte','Email de suporte técnico'),(5,'Comercial','Email para assuntos comerciais'),(6,'Marketing','Email para marketing e publicidade'),(7,'RH','Email do departamento de recursos humanos'),(8,'TI','Email do departamento de TI'),(9,'Vendas','Email do departamento de vendas'),(10,'Serviço','Email do departamento de serviços'),(11,'Parcerias','Email para parcerias comerciais'),(12,'Legal','Email do departamento jurídico'),(13,'Administrativo','Email do departamento administrativo'),(14,'Diretoria','Email da diretoria executiva'),(15,'Geral','Email geral da empresa'),(16,'Promocional','Email utilizado para promover produtos e serviços'),(17,'Transacional','Email enviado para confirmar transações e mudanças de status'),(18,'Boas-vindas','Email de boas-vindas para novos usuários'),(19,'Newsletter','Email informativo enviado regularmente para assinantes'),(21,'Reativação','Email destinado a reativar usuários inativos'),(22,'Informativo','Email que fornece informações importantes e atualizações'),(23,'Convite','Email enviado para convidar para eventos ou atividades'),(24,'Feedback','Email solicitando feedback ou opiniões dos usuários'),(25,'Aviso de Segurança','Email enviado para informar sobre questões de segurança e proteção de contas'),(39,'Promocional','Email utilizado para promover produtos e serviços'),(40,'Transacional','Email enviado para confirmar transações e mudanças de status'),(41,'Boas-vindas','Email de boas-vindas para novos usuários'),(42,'Promocional','E-mails utilizados para promover produtos e serviços.'),(43,'Transacional','E-mails enviados para confirmar transações e mudanças de status.'),(44,'Boas-vindas','E-mails de boas-vindas para novos usuários.'),(45,'Newsletter','E-mails informativos enviados regularmente para assinantes.'),(46,'Follow-up','E-mails de acompanhamento após uma interação anterior.'),(47,'Reativação','E-mails destinados a reativar usuários inativos.'),(48,'Informativo','E-mails que fornecem informações importantes e atualizações.'),(49,'Convite','E-mails enviados para convidar para eventos ou atividades.'),(50,'Feedback','E-mails solicitando feedback ou opiniões dos usuários.'),(51,'Aviso de Segurança','E-mails enviados para informar sobre questões de segurança e proteção de contas.'),(52,'Feedbacck','E-mails utilizados para promover  serviços.');
/*!40000 ALTER TABLE `tipo_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_endereco`
--

DROP TABLE IF EXISTS `tipo_endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_endereco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_endereco`
--

LOCK TABLES `tipo_endereco` WRITE;
/*!40000 ALTER TABLE `tipo_endereco` DISABLE KEYS */;
INSERT INTO `tipo_endereco` VALUES (1,'Residencial','Endereço residencial'),(2,'Comercial','Endereço comercial'),(3,'Cobrança','Endereço de cobrança'),(4,'Entrega','Endereço de entrega'),(5,'Correspondência','Endereço de correspondência'),(6,'Fiscal','Endereço fiscal'),(7,'Filial','Endereço de filial'),(8,'Matriz','Endereço da matriz'),(9,'Temporário','Endereço temporário'),(10,'Outro','Outro tipo de endereço'),(11,'Sede','Endereço da sede'),(12,'Provisório','Endereço provisório'),(13,'Posto Avançado','Endereço de posto avançado'),(14,'Depósito','Endereço de depósito'),(15,'Distribuição','Endereço de distribuição');
/*!40000 ALTER TABLE `tipo_endereco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_fornecedor`
--

DROP TABLE IF EXISTS `tipo_fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_fornecedor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_fornecedor`
--

LOCK TABLES `tipo_fornecedor` WRITE;
/*!40000 ALTER TABLE `tipo_fornecedor` DISABLE KEYS */;
INSERT INTO `tipo_fornecedor` VALUES (1,'Materiais','Fornecedor de materiais diversos'),(2,'Serviços','Fornecedor de serviços gerais'),(3,'Equipamentos','Fornecedor de equipamentos'),(4,'Tecnologia','Fornecedor de tecnologia'),(5,'Alimentos','Fornecedor de alimentos'),(6,'Bebidas','Fornecedor de bebidas'),(7,'Construção','Fornecedor de materiais de construção'),(8,'Limpeza','Fornecedor de produtos de limpeza'),(9,'Móveis','Fornecedor de móveis'),(10,'Eletrodomésticos','Fornecedor de eletrodomésticos'),(11,'Automóveis','Fornecedor de automóveis'),(12,'Peças','Fornecedor de peças automotivas'),(13,'Roupas','Fornecedor de roupas e vestuário'),(14,'Calçados','Fornecedor de calçados'),(15,'Papelaria','Fornecedor de produtos de papelaria');
/*!40000 ALTER TABLE `tipo_fornecedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_relacionamento`
--

DROP TABLE IF EXISTS `tipo_relacionamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_relacionamento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_relacionamento`
--

LOCK TABLES `tipo_relacionamento` WRITE;
/*!40000 ALTER TABLE `tipo_relacionamento` DISABLE KEYS */;
INSERT INTO `tipo_relacionamento` VALUES (1,'Cliente','Relacionamento com cliente'),(2,'Fornecedor','Relacionamento com fornecedor'),(3,'Parceiro','Relacionamento com parceiro'),(4,'Colaborador','Relacionamento com colaborador'),(5,'Associado','Relacionamento com associado'),(6,'Investidor','Relacionamento com investidor'),(7,'Consultor','Relacionamento com consultor'),(8,'Autônomo','Relacionamento com autônomo'),(9,'Freelancer','Relacionamento com freelancer'),(10,'Distribuidor','Relacionamento com distribuidor'),(11,'Revendedor','Relacionamento com revendedor'),(12,'Franqueado','Relacionamento com franqueado'),(13,'Licenciado','Relacionamento com licenciado'),(14,'Representante','Relacionamento com representante'),(15,'Outro','Outro tipo de relacionamento');
/*!40000 ALTER TABLE `tipo_relacionamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_telefone`
--

DROP TABLE IF EXISTS `tipo_telefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_telefone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_telefone`
--

LOCK TABLES `tipo_telefone` WRITE;
/*!40000 ALTER TABLE `tipo_telefone` DISABLE KEYS */;
INSERT INTO `tipo_telefone` VALUES (1,'Residencial','Telefone residencial'),(2,'Comercial','Telefone comercial'),(3,'Celular','Telefone celular'),(4,'Fax','Número de fax'),(5,'PABX','Número de PABX'),(6,'Ramal','Ramal de telefone'),(7,'Recado','Número para recados'),(8,'Whatsapp','Número do WhatsApp'),(9,'Skype','Número do Skype'),(10,'Telegram','Número do Telegram'),(11,'Emergência','Número para emergências'),(12,'VoIP','Telefone VoIP'),(13,'Outro','Outro tipo de telefone'),(14,'Viber','Número do Viber'),(15,'Messenger','Número do Messenger');
/*!40000 ALTER TABLE `tipo_telefone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidade_produto`
--

DROP TABLE IF EXISTS `unidade_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidade_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(15) DEFAULT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidade_produto`
--

LOCK TABLES `unidade_produto` WRITE;
/*!40000 ALTER TABLE `unidade_produto` DISABLE KEYS */;
INSERT INTO `unidade_produto` VALUES (1,'Unidade','Medido em unidades'),(2,'Caixa','Medido em caixas'),(3,'Litro','Medido em litros'),(4,'Quilograma','Medido em quilogramas'),(5,'Metro','Medido em metros'),(6,'Pacote','Medido em pacotes'),(7,'Par','Medido em pares'),(8,'Dúzia','Medido em dúzias'),(9,'Kit','Medido em kits'),(10,'Galão','Medido em galões'),(11,'Mililitro','Medido em mililitros'),(12,'Centímetro','Medido em centímetros'),(13,'Metro Quadrado','Medido em metros quadrados'),(14,'Metro Cúbico','Medido em metros cúbicos'),(15,'Miligrama','Medido em miligramas');
/*!40000 ALTER TABLE `unidade_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `papel_id` int DEFAULT NULL,
  `colaborador_id` int DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `senha` varchar(30) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `papel_id` (`papel_id`),
  KEY `colaborador_id` (`colaborador_id`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`papel_id`) REFERENCES `papel` (`id`),
  CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`colaborador_id`) REFERENCES `colaborador` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,1,1,'usuario1','senha1','2020-01-01'),(2,2,2,'usuario2','senha2','2020-02-01'),(3,3,3,'usuario3','senha3','2020-03-01'),(4,4,4,'usuario4','senha4','2020-04-01'),(5,5,5,'usuario5','senha5','2020-05-01'),(6,6,6,'usuario6','senha6','2020-06-01'),(7,7,7,'usuario7','senha7','2020-07-01'),(8,8,8,'usuario8','senha8','2020-08-01'),(9,9,9,'usuario9','senha9','2020-09-01'),(10,10,10,'usuario10','senha10','2020-10-01'),(11,11,11,'usuario11','senha11','2020-11-01'),(12,12,12,'usuario12','senha12','2020-12-01'),(13,13,13,'usuario13','senha13','2021-01-01'),(14,14,14,'usuario14','senha14','2021-02-01'),(15,15,15,'usuario15','senha15','2021-03-01');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-17 20:27:13
